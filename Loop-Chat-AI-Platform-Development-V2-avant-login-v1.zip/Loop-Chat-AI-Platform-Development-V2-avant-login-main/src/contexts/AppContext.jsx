import React, { createContext, useContext, useState, useEffect } from 'react'
import { agentsService, conversationsService, messagesService, statisticsService, userSettingsService, apiKeysService } from '../services/supabaseService'

const AppContext = createContext()

export const useApp = () => {
  const context = useContext(AppContext)
  if (!context) {
    throw new Error('useApp must be used within an AppProvider')
  }
  return context
}

export const AppProvider = ({ children }) => {
  // États principaux
  const [language, setLanguage] = useState('fr')
  const [agents, setAgents] = useState({})
  const [conversations, setConversations] = useState({})
  const [messages, setMessages] = useState({})
  const [webhookUrls, setWebhookUrls] = useState({})
  const [isWebhookConnected, setIsWebhookConnected] = useState({})
  const [stats, setStats] = useState({ totalInteractions: 0, agentStats: {} })
  const [editingAgent, setEditingAgent] = useState(null)
  const [isSidebarOpen, setIsSidebarOpen] = useState(true)
  const [activeChat, setActiveChat] = useState('general')
  const [isLoading, setIsLoading] = useState(true)

  // Fonction pour récupérer les données depuis localStorage (fallback)
  const getSavedData = (key, defaultValue) => {
    try {
      const savedData = localStorage.getItem(key)
      return savedData ? JSON.parse(savedData) : defaultValue
    } catch (error) {
      console.error(`Error loading ${key} from localStorage:`, error)
      return defaultValue
    }
  }

  // Charger les données depuis Supabase
  const loadDataFromSupabase = async () => {
    try {
      setIsLoading(true)

      // Charger les agents
      const agentsData = await agentsService.getAll()
      const agentsMap = {}
      const webhooksMap = {}
      const connectionsMap = {}

      agentsData.forEach(agent => {
        agentsMap[agent.agent_id] = {
          id: agent.agent_id,
          name: agent.name,
          description: agent.description,
          color: agent.color,
          icon: agent.icon,
          isDefault: agent.is_default
        }
        webhooksMap[agent.agent_id] = agent.webhook_url_in || ''
        connectionsMap[agent.agent_id] = agent.is_connected || false
      })

      setAgents(agentsMap)
      setWebhookUrls(webhooksMap)
      setIsWebhookConnected(connectionsMap)

      // Charger les conversations
      const conversationsData = await conversationsService.getAll()
      const conversationsMap = {}

      conversationsData.forEach(conv => {
        conversationsMap[conv.conversation_id] = {
          id: conv.conversation_id,
          title: conv.title,
          agentId: conv.agent_id,
          created: new Date(conv.created_at),
          lastUpdated: new Date(conv.updated_at)
        }
      })

      setConversations(conversationsMap)

      // Charger les messages pour chaque conversation
      const messagesMap = {}
      for (const convId of Object.keys(conversationsMap)) {
        const convMessages = await messagesService.getByConversation(convId)
        messagesMap[convId] = convMessages.map(msg => ({
          id: parseInt(msg.message_id),
          content: msg.content,
          sender: msg.sender,
          timestamp: new Date(msg.timestamp)
        }))
      }

      setMessages(messagesMap)

      // Charger les statistiques
      const statisticsData = await statisticsService.getAll()
      const agentStats = {}
      let totalInteractions = 0

      statisticsData.forEach(stat => {
        agentStats[stat.agent_id] = {
          count: stat.interaction_count,
          name: agentsMap[stat.agent_id]?.name || 'Unknown'
        }
        totalInteractions += stat.interaction_count
      })

      setStats({ totalInteractions, agentStats })

      // Charger les paramètres utilisateur
      const userSettings = await userSettingsService.get()
      if (userSettings) {
        setLanguage(userSettings.language || 'fr')
      }
    } catch (error) {
      console.error('Error loading data from Supabase:', error)
      
      // Fallback vers localStorage
      const savedAgents = getSavedData('agents', {})
      const savedConversations = getSavedData('conversations', {})
      const savedMessages = getSavedData('chatHistory', {})
      const savedWebhooks = getSavedData('webhookUrls', {})
      const savedConnections = getSavedData('isWebhookConnected', {})
      const savedStats = getSavedData('stats', { totalInteractions: 0, agentStats: {} })
      const savedLanguage = getSavedData('language', 'fr')
      
      setAgents(savedAgents)
      setConversations(savedConversations)
      setMessages(savedMessages)
      setWebhookUrls(savedWebhooks)
      setIsWebhookConnected(savedConnections)
      setStats(savedStats)
      setLanguage(savedLanguage)
    } finally {
      setIsLoading(false)
    }
  }

  // Charger les données au démarrage
  useEffect(() => {
    loadDataFromSupabase()
  }, [])

  // Sauvegarder dans localStorage en parallèle (backup)
  useEffect(() => {
    if (!isLoading) {
      localStorage.setItem('agents', JSON.stringify(agents))
    }
  }, [agents, isLoading])

  useEffect(() => {
    if (!isLoading) {
      localStorage.setItem('conversations', JSON.stringify(conversations))
    }
  }, [conversations, isLoading])

  useEffect(() => {
    if (!isLoading) {
      localStorage.setItem('chatHistory', JSON.stringify(messages))
    }
  }, [messages, isLoading])

  useEffect(() => {
    if (!isLoading) {
      localStorage.setItem('webhookUrls', JSON.stringify(webhookUrls))
    }
  }, [webhookUrls, isLoading])

  useEffect(() => {
    if (!isLoading) {
      localStorage.setItem('isWebhookConnected', JSON.stringify(isWebhookConnected))
    }
  }, [isWebhookConnected, isLoading])

  useEffect(() => {
    if (!isLoading) {
      localStorage.setItem('stats', JSON.stringify(stats))
    }
  }, [stats, isLoading])

  useEffect(() => {
    if (!isLoading) {
      localStorage.setItem('language', JSON.stringify(language))
      
      // Sauvegarder les paramètres utilisateur
      userSettingsService.update('default', { language, settings: {} })
        .catch(console.error)
    }
  }, [language, isLoading])

  // Traductions
  const translations = {
    fr: {
      appTitle: 'Loop Chat',
      general: 'Canal Général',
      aiManager: 'IA Manager',
      marketingAgent: 'Agent Marketing',
      techAgent: 'Agent Technique',
      supportAgent: 'Agent Support',
      settings: 'Paramètres',
      statistics: 'Statistiques',
      tutorial: 'Tutoriel',
      webhookUrl: 'URL du Webhook',
      testConnection: 'Tester la connexion',
      connected: 'Connecté',
      disconnected: 'Déconnecté',
      typeMessage: 'Tapez votre message...',
      send: 'Envoyer',
      totalInteractions: 'Interactions totales',
      agentInteractions: 'Interactions par agent',
      dailyActivity: 'Activité quotidienne',
      language: 'Langue',
      save: 'Sauvegarder',
      cancel: 'Annuler',
      connectionTest: 'Test de connexion',
      testMessage: 'Message de test envoyé avec succès',
      testError: 'Erreur lors du test de connexion',
      welcome: 'Bienvenue dans Loop Chat! Comment puis-je vous aider aujourd\'hui?',
      editAgent: 'Modifier l\'agent',
      agentName: 'Nom de l\'agent',
      agentDescription: 'Description',
      agentColor: 'Couleur',
      agentIcon: 'Icône',
      confirmDelete: 'Êtes-vous sûr de vouloir supprimer cet agent?',
      confirmDeleteConversation: 'Êtes-vous sûr de vouloir supprimer cette conversation?',
      confirmRegenerateKey: 'Êtes-vous sûr de vouloir régénérer la clé API ? Toutes les intégrations existantes devront être mises à jour avec la nouvelle clé.',
      keyRegenerated: 'La clé API a été régénérée avec succès. Veillez à mettre à jour vos intégrations avec la nouvelle clé.',
      keyRegenerationError: 'Une erreur s\'est produite lors de la régénération de la clé API.',
      activeAgents: 'Agents actifs',
      availableAgents: 'Agents disponibles',
      noMessages: 'Aucun message. Commencez à discuter!',
      noConversations: 'Aucune conversation active',
      startConversationFromAgents: 'Créez une nouvelle conversation depuis la liste des agents',
      webhookSettings: 'Paramètres du webhook',
      generalWebhook: 'Webhook du canal général',
      agentWebhook: 'Webhook de l\'agent',
      addAgent: 'Ajouter un agent',
      deleteAgent: 'Supprimer l\'agent',
      newAgent: 'Nouvel Agent',
      newConversation: 'Nouvelle conversation',
      configureExperience: 'Configurez votre expérience Loop Chat',
      general: 'Général',
      webhooks: 'Webhooks',
      webhookFor: 'URL du webhook pour',
      webhookPlatforms: '(n8n, Make.com, etc.)',
      testing: 'Test...',
      success: 'Succès',
      failure: 'Échec',
      online: 'En ligne',
      offline: 'Hors ligne',
      preview: 'Aperçu',
      webhookConfiguration: 'Configuration du webhook',
      webhookTip1: '• Utilisez n8n, Make.com ou Zapier pour créer votre webhook',
      webhookTip2: '• Le webhook recevra les messages au format JSON',
      webhookTip3: '• Testez la connexion avant de commencer à utiliser les agents',
      webhookTip4: '• Chaque agent peut avoir son propre webhook dédié',
      analyzePerformance: 'Analysez les performances de vos agents IA',
      detailsByAgent: 'Détails par agent',
      interactions: 'interactions',
      learnToUse: 'Apprenez à utiliser Loop Chat efficacement',
      step: 'Étape',
      on: 'sur',
      completed: '% complété',
      practicalTips: 'Conseils pratiques',
      previous: 'Précédent',
      next: 'Suivant',
      quickStart: 'Démarrage rapide',
      quickStartDesc: 'Commencez immédiatement avec le canal général',
      configuration: 'Configuration',
      configurationDesc: 'Configurez votre webhook et vos préférences',
      statisticsDesc: 'Analysez vos interactions et performances',
      generalChannel: 'Canal Général',
      conversations: 'Conversations',
      specializedAgent: 'Agent spécialisé',
      chatWith: 'Chat avec'
    },
    en: {
      appTitle: 'Loop Chat',
      general: 'General Channel',
      aiManager: 'AI Manager',
      marketingAgent: 'Marketing Agent',
      techAgent: 'Tech Agent',
      supportAgent: 'Support Agent',
      settings: 'Settings',
      statistics: 'Statistics',
      tutorial: 'Tutorial',
      webhookUrl: 'Webhook URL',
      testConnection: 'Test Connection',
      connected: 'Connected',
      disconnected: 'Disconnected',
      typeMessage: 'Type your message...',
      send: 'Send',
      totalInteractions: 'Total Interactions',
      agentInteractions: 'Agent Interactions',
      dailyActivity: 'Daily Activity',
      language: 'Language',
      save: 'Save',
      cancel: 'Cancel',
      connectionTest: 'Connection Test',
      testMessage: 'Test message sent successfully',
      testError: 'Error testing connection',
      welcome: 'Welcome to Loop Chat! How can I help you today?',
      editAgent: 'Edit Agent',
      agentName: 'Agent Name',
      agentDescription: 'Description',
      agentColor: 'Color',
      agentIcon: 'Icon',
      confirmDelete: 'Are you sure you want to delete this agent?',
      confirmDeleteConversation: 'Are you sure you want to delete this conversation?',
      confirmRegenerateKey: 'Are you sure you want to regenerate the API key? All existing integrations will need to be updated with the new key.',
      keyRegenerated: 'API key has been successfully regenerated. Be sure to update your integrations with the new key.',
      keyRegenerationError: 'An error occurred while regenerating the API key.',
      activeAgents: 'Active Agents',
      availableAgents: 'Available Agents',
      noMessages: 'No messages. Start chatting!',
      noConversations: 'No active conversations',
      startConversationFromAgents: 'Create a new conversation from the agents list',
      webhookSettings: 'Webhook settings',
      generalWebhook: 'General channel webhook',
      agentWebhook: 'Agent webhook',
      addAgent: 'Add Agent',
      deleteAgent: 'Delete Agent',
      newAgent: 'New Agent',
      newConversation: 'New conversation',
      configureExperience: 'Configure your Loop Chat experience',
      general: 'General',
      webhooks: 'Webhooks',
      webhookFor: 'Webhook URL for',
      webhookPlatforms: '(n8n, Make.com, etc.)',
      testing: 'Testing...',
      success: 'Success',
      failure: 'Failure',
      online: 'Online',
      offline: 'Offline',
      preview: 'Preview',
      webhookConfiguration: 'Webhook Configuration',
      webhookTip1: '• Use n8n, Make.com or Zapier to create your webhook',
      webhookTip2: '• The webhook will receive messages in JSON format',
      webhookTip3: '• Test the connection before starting to use agents',
      webhookTip4: '• Each agent can have its own dedicated webhook',
      analyzePerformance: 'Analyze your AI agents performance',
      detailsByAgent: 'Details by agent',
      interactions: 'interactions',
      learnToUse: 'Learn to use Loop Chat effectively',
      step: 'Step',
      on: 'of',
      completed: '% completed',
      practicalTips: 'Practical Tips',
      previous: 'Previous',
      next: 'Next',
      quickStart: 'Quick Start',
      quickStartDesc: 'Start immediately with the general channel',
      configuration: 'Configuration',
      configurationDesc: 'Configure your webhook and preferences',
      statisticsDesc: 'Analyze your interactions and performance',
      generalChannel: 'General Channel',
      conversations: 'Conversations',
      specializedAgent: 'Specialized agent',
      chatWith: 'Chat with'
    }
  }

  const t = (key) => translations[language][key] || key

  // Fonctions pour gérer les messages
  const addMessage = async (chatId, message) => {
    const newMessage = { ...message, timestamp: new Date(), conversationId: chatId }
    
    // Ajouter à l'état local
    setMessages(prev => ({
      ...prev,
      [chatId]: [...(prev[chatId] || []), newMessage]
    }))
    
    // Sauvegarder dans Supabase
    try {
      await messagesService.create(newMessage)
    } catch (error) {
      console.error('Error saving message to Supabase:', error)
    }
    
    // Mettre à jour la conversation
    if (conversations[chatId]) {
      const updatedConversation = { ...conversations[chatId], lastUpdated: new Date() }
      
      setConversations(prev => ({
        ...prev,
        [chatId]: updatedConversation
      }))
      
      try {
        await conversationsService.update(chatId, { title: updatedConversation.title })
      } catch (error) {
        console.error('Error updating conversation in Supabase:', error)
      }
    }
    
    // Mettre à jour les statistiques
    const agentId = conversations[chatId]?.agentId || chatId
    
    setStats(prev => ({
      ...prev,
      totalInteractions: prev.totalInteractions + 1,
      agentStats: {
        ...prev.agentStats,
        [agentId]: {
          ...prev.agentStats[agentId],
          count: (prev.agentStats[agentId]?.count || 0) + 1
        }
      }
    }))
    
    try {
      await statisticsService.updateInteractionCount(agentId)
    } catch (error) {
      console.error('Error updating statistics in Supabase:', error)
    }
  }

  // Generate API key
  const generateApiKey = () => {
    return 'lc_' + Math.random().toString(36).substr(2, 32) + Date.now().toString(36);
  }

  // Get API key for an agent
  const getAgentApiKey = async (agentId) => {
    try {
      // First try to get from apiKeysService
      const apiKeyData = await apiKeysService.getByAgent(agentId);
      if (apiKeyData && apiKeyData.api_key) {
        return apiKeyData.api_key;
      }
      
      // Fallback to agents table
      const agentData = await agentsService.getById(agentId);
      return agentData?.api_key || null;
    } catch (error) {
      console.error(`Error getting API key for agent ${agentId}:`, error);
      return null;
    }
  }

  // Rotate API key
  const rotateApiKey = async (agentId) => {
    const newApiKey = generateApiKey();
    
    try {
      // Try to rotate using apiKeysService first
      await apiKeysService.rotate(agentId, newApiKey);
      
      // Also update in agents table
      await agentsService.update(agentId, { 
        ...agents[agentId],
        apiKey: newApiKey
      });
      
      return newApiKey;
    } catch (error) {
      console.error(`Error rotating API key for agent ${agentId}:`, error);
      throw new Error('Failed to rotate API key');
    }
  }

  // Get response URL for an agent
  const getAgentResponseUrl = (agentId) => {
    return `https://tvpisaticebdoxdrvdwa.supabase.co/functions/v1/webhook-response/${agentId}`;
  }

  // Fonction pour tester les webhooks
  const testWebhook = async (agentId) => {
    const webhookUrl = webhookUrls[agentId]
    if (!webhookUrl) return false
    
    try {
      const response = await fetch(webhookUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          message: 'test',
          agent: agents[agentId].name,
          timestamp: new Date().toISOString()
        })
      })
      
      if (response.ok) {
        setIsWebhookConnected(prev => ({
          ...prev,
          [agentId]: true
        }))
        
        // Mettre à jour dans Supabase
        try {
          await agentsService.update(agentId, {
            ...agents[agentId],
            webhookUrl: webhookUrl,
            isConnected: true
          })
        } catch (error) {
          console.error('Error updating agent connection in Supabase:', error)
        }
        
        return true
      }
      
      return false
    } catch (error) {
      console.error(`Webhook test failed for ${agentId}:`, error)
      setIsWebhookConnected(prev => ({
        ...prev,
        [agentId]: false
      }))
      
      return false
    }
  }

  // Fonction pour mettre à jour les URLs de webhook
  const updateWebhookUrl = async (agentId, url) => {
    setWebhookUrls(prev => ({
      ...prev,
      [agentId]: url
    }))
    
    setIsWebhookConnected(prev => ({
      ...prev,
      [agentId]: false
    }))
    
    try {
      await agentsService.update(agentId, {
        ...agents[agentId],
        webhookUrl: url,
        webhookUrlIn: url,
        isConnected: false
      })
    } catch (error) {
      console.error('Error updating webhook URL in Supabase:', error)
    }
  }

  // Fonction pour mettre à jour un agent
  const updateAgent = async (agentId, agentData) => {
    console.log('🔄 Mise à jour de l\'agent:', agentId, agentData)
    const updatedAgent = { ...agents[agentId], ...agentData }
    
    // Mettre à jour l'état local immédiatement
    setAgents(prev => ({
      ...prev,
      [agentId]: updatedAgent
    }))
    
    // Sauvegarder dans Supabase
    try {
      const supabaseResult = await agentsService.update(agentId, {
        name: updatedAgent.name,
        description: updatedAgent.description,
        color: updatedAgent.color,
        icon: updatedAgent.icon,
        webhookUrl: webhookUrls[agentId] || '',
        isConnected: isWebhookConnected[agentId] || false
      })
      
      console.log('✅ Agent mis à jour dans Supabase:', supabaseResult)
    } catch (error) {
      console.error('❌ Erreur lors de la mise à jour de l\'agent dans Supabase:', error)
    }
    
    // Mettre à jour les statistiques si le nom a changé
    if (agentData.name && agentData.name !== agents[agentId]?.name) {
      setStats(prev => ({
        ...prev,
        agentStats: {
          ...prev.agentStats,
          [agentId]: {
            ...prev.agentStats[agentId],
            name: agentData.name
          }
        }
      }))
    }
  }

  // Fonction pour ajouter un agent - CORRECTION COMPLÈTE
  const addAgent = async (agentData) => {
    console.log('🆕 Création d\'un nouvel agent:', agentData)
    const newAgentId = `agent_${Date.now()}`
    const agentName = agentData.name || t('newAgent')
    const newApiKey = generateApiKey()
    
    const newAgent = {
      id: newAgentId,
      name: agentName,
      description: agentData.description || '',
      color: agentData.color || 'bg-gray-500',
      icon: agentData.icon || 'MessageCircle',
      isDefault: false,
      apiKey: newApiKey,
      webhookUrlIn: agentData.webhookUrlIn || '',
      webhookUrlOut: getAgentResponseUrl(newAgentId)
    }
    
    console.log('📝 Données du nouvel agent:', newAgent)
    
    // Mettre à jour l'état local immédiatement
    setAgents(prev => ({
      ...prev,
      [newAgentId]: newAgent
    }))
    
    setWebhookUrls(prev => ({
      ...prev,
      [newAgentId]: agentData.webhookUrlIn || ''
    }))
    
    setIsWebhookConnected(prev => ({
      ...prev,
      [newAgentId]: false
    }))
    
    setStats(prev => ({
      ...prev,
      agentStats: {
        ...prev.agentStats,
        [newAgentId]: {
          count: 0,
          name: agentName
        }
      }
    }))
    
    // Sauvegarder dans Supabase
    try {
      console.log('💾 Sauvegarde dans Supabase...')
      const supabaseResult = await agentsService.create({
        id: newAgentId,
        name: newAgent.name,
        description: newAgent.description,
        color: newAgent.color,
        icon: newAgent.icon,
        isDefault: newAgent.isDefault,
        webhookUrl: '',
        webhookUrlIn: newAgent.webhookUrlIn,
        webhookUrlOut: newAgent.webhookUrlOut,
        apiKey: newApiKey,
        isConnected: false
      })
      
      // Create API key entry
      await apiKeysService.create(newAgentId, newApiKey);
      
      console.log('✅ Agent créé dans Supabase:', supabaseResult)
    } catch (error) {
      console.error('❌ Erreur lors de la création de l\'agent dans Supabase:', error)
      // En cas d'erreur, on garde l'agent dans l'état local pour permettre la modification
    }
    
    return newAgentId
  }

  // Fonction pour supprimer un agent
  const deleteAgent = async (agentId) => {
    if (agents[agentId]?.isDefault) {
      return false
    }
    
    console.log('🗑️ Suppression de l\'agent:', agentId)
    
    setAgents(prev => {
      const newAgents = { ...prev }
      delete newAgents[agentId]
      return newAgents
    })
    
    setWebhookUrls(prev => {
      const newWebhooks = { ...prev }
      delete newWebhooks[agentId]
      return newWebhooks
    })
    
    setIsWebhookConnected(prev => {
      const newConnections = { ...prev }
      delete newConnections[agentId]
      return newConnections
    })
    
    // Supprimer les conversations associées
    const conversationsToDelete = Object.entries(conversations)
      .filter(([_, conv]) => conv.agentId === agentId)
      .map(([id]) => id)
    
    for (const convId of conversationsToDelete) {
      await deleteConversation(convId)
    }
    
    setStats(prev => ({
      ...prev,
      agentStats: { ...prev.agentStats, [agentId]: undefined }
    }))
    
    try {
      await agentsService.delete(agentId)
      console.log('✅ Agent supprimé de Supabase')
    } catch (error) {
      console.error('❌ Erreur lors de la suppression de l\'agent dans Supabase:', error)
    }
    
    if (conversations[activeChat]?.agentId === agentId) {
      setActiveChat('general')
    }
    
    return true
  }

  // Fonction pour créer une conversation
  const createConversation = async (agentId) => {
    if (!agents[agentId]) return null
    
    const conversationId = `conv_${Date.now()}`
    const newConversation = {
      id: conversationId,
      title: `${t('chatWith')} ${agents[agentId].name}`,
      agentId: agentId,
      created: new Date(),
      lastUpdated: new Date()
    }
    
    setConversations(prev => ({
      ...prev,
      [conversationId]: newConversation
    }))
    
    setMessages(prev => ({
      ...prev,
      [conversationId]: []
    }))
    
    try {
      await conversationsService.create(newConversation)
    } catch (error) {
      console.error('Error creating conversation in Supabase:', error)
    }
    
    // Ajouter un message de bienvenue
    setTimeout(() => {
      addMessage(conversationId, {
        id: Date.now(),
        content: language === 'fr' 
          ? `Bonjour, je suis ${agents[agentId].name}. Comment puis-je vous aider ?` 
          : `Hello, I'm ${agents[agentId].name}. How can I help you?`,
        sender: 'ai',
        timestamp: new Date()
      })
    }, 100)
    
    return conversationId
  }

  // Fonction pour supprimer une conversation
  const deleteConversation = async (conversationId) => {
    setMessages(prev => {
      const newMessages = { ...prev }
      delete newMessages[conversationId]
      return newMessages
    })
    
    setConversations(prev => {
      const newConversations = { ...prev }
      delete newConversations[conversationId]
      return newConversations
    })
    
    try {
      await messagesService.deleteByConversation(conversationId)
      await conversationsService.delete(conversationId)
    } catch (error) {
      console.error('Error deleting conversation from Supabase:', error)
    }
    
    if (activeChat === conversationId) {
      const firstAvailableConv = Object.keys(conversations).find(id => id !== conversationId)
      setActiveChat(firstAvailableConv || 'general')
    }
    
    return true
  }

  // Fonction pour envoyer un message
  const sendMessage = async (chatId, content) => {
    const userMessage = {
      id: Date.now(),
      content,
      sender: 'user',
      timestamp: new Date()
    }
    
    await addMessage(chatId, userMessage)
    
    const agentId = conversations[chatId]?.agentId || chatId
    const webhookUrl = webhookUrls[agentId]
    let aiResponseContent = ''
    
    if (webhookUrl && isWebhookConnected[agentId]) {
      try {
        const response = await fetch(webhookUrl, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            message: content,
            agent: agents[agentId].name,
            timestamp: new Date().toISOString()
          })
        })
        
        if (response.ok) {
          try {
            const data = await response.json()
            aiResponseContent = data.response || (
              language === 'fr' 
                ? `Réponse de ${agents[agentId].name}: ${content}` 
                : `Response from ${agents[agentId].name}: ${content}`
            )
          } catch {
            aiResponseContent = language === 'fr' 
              ? `Réponse de ${agents[agentId].name}: ${content}` 
              : `Response from ${agents[agentId].name}: ${content}`
          }
        } else {
          aiResponseContent = language === 'fr' 
            ? `Erreur de connexion au webhook pour ${agents[agentId].name}. Veuillez vérifier les paramètres.` 
            : `Webhook connection error for ${agents[agentId].name}. Please check settings.`
        }
      } catch (error) {
        console.error('Error sending message to webhook:', error)
        aiResponseContent = language === 'fr' 
          ? `Erreur de connexion au webhook pour ${agents[agentId].name}. Veuillez vérifier les paramètres.` 
          : `Webhook connection error for ${agents[agentId].name}. Please check settings.`
      }
    } else {
      aiResponseContent = language === 'fr' 
        ? `Réponse simulée de ${agents[agentId].name}: ${content}` 
        : `Simulated response from ${agents[agentId].name}: ${content}`
    }
    
    setTimeout(() => {
      const aiMessage = {
        id: Date.now() + 1,
        content: aiResponseContent,
        sender: 'ai',
        timestamp: new Date()
      }
      
      addMessage(chatId, aiMessage)
    }, 1000)
  }

  const value = {
    language,
    setLanguage,
    webhookUrls,
    updateWebhookUrl,
    isWebhookConnected,
    setIsWebhookConnected,
    isSidebarOpen,
    setIsSidebarOpen,
    activeChat,
    setActiveChat,
    messages,
    agents,
    updateAgent,
    addAgent,
    deleteAgent,
    stats,
    t,
    addMessage,
    testWebhook,
    sendMessage,
    editingAgent,
    setEditingAgent,
    conversations,
    setConversations,
    deleteConversation,
    createConversation,
    isLoading,
    generateApiKey,
    getAgentApiKey,
    rotateApiKey,
    getAgentResponseUrl
  }

  return (
    <AppContext.Provider value={value}>
      {children}
    </AppContext.Provider>
  )
}