import React from 'react';
import { HashRouter as Router } from 'react-router-dom';
import { AppProvider } from './contexts/AppContext';
import Layout from './components/Layout';
import './App.css';

function App() {
  return (
    <Router>
      <AppProvider>
        <div className="app-container">
          <Layout />
        </div>
      </AppProvider>
    </Router>
  );
}

export default App;