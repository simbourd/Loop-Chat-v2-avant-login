import React from 'react';
import { AlertTriangle } from 'lucide-react';

const SafeIcon = ({ icon: IconComponent, className = "", ...props }) => {
  if (!IconComponent) {
    return <AlertTriangle className={className} {...props} />;
  }
  
  try {
    return <IconComponent className={className} {...props} />;
  } catch (error) {
    console.warn('Error rendering icon:', error);
    return <AlertTriangle className={className} {...props} />;
  }
};

export default SafeIcon;