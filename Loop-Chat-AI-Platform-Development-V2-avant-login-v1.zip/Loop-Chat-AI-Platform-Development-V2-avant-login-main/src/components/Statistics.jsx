import React from 'react';
import { motion } from 'framer-motion';
import { useApp } from '../contexts/AppContext';
import { BarChart3, MessageSquare, Users } from 'lucide-react';
import ReactECharts from 'echarts-for-react';

const Statistics = () => {
  const { stats, t, agents } = useApp();

  // Simplified chart for agent interactions
  const agentChartOptions = {
    title: {
      text: t('agentInteractions'),
      left: 'center',
      textStyle: {
        fontSize: 16,
        fontWeight: 'bold'
      }
    },
    tooltip: {
      trigger: 'item'
    },
    series: [
      {
        type: 'pie',
        radius: '60%',
        data: Object.entries(stats.agentStats || {})
          .filter(([id, agent]) => agent && agent.count > 0)
          .map(([id, agent]) => ({
            value: agent.count,
            name: agent.name,
            // Match colors from agent settings
            itemStyle: {
              color: agents[id]?.color === 'bg-teal-500' ? '#14b8a6' :
                agents[id]?.color === 'bg-yellow-500' ? '#eab308' :
                agents[id]?.color === 'bg-green-500' ? '#22c55e' :
                agents[id]?.color === 'bg-blue-500' ? '#3b82f6' :
                agents[id]?.color === 'bg-red-500' ? '#ef4444' :
                agents[id]?.color === 'bg-purple-500' ? '#a855f7' :
                agents[id]?.color === 'bg-pink-500' ? '#ec4899' :
                '#6b7280'
            }
          })),
        emphasis: {
          itemStyle: {
            shadowBlur: 10,
            shadowOffsetX: 0,
            shadowColor: 'rgba(0, 0, 0, 0.5)'
          }
        }
      }
    ]
  };

  // Only show essential stats cards
  const statCards = [
    {
      title: t('totalInteractions'),
      value: stats.totalInteractions || 0,
      icon: MessageSquare,
      color: 'bg-teal-500'
    },
    {
      title: t('activeAgents'),
      value: Object.values(agents).length,
      icon: Users,
      color: 'bg-yellow-500'
    }
  ];

  return (
    <div className="flex-1 overflow-hidden flex flex-col h-full">
      <div className="flex-1 overflow-y-auto">
        <div className="p-6 max-w-4xl mx-auto pb-20">
          {/* Header */}
          <div className="mb-8">
            <div className="flex items-center space-x-3 mb-2">
              <BarChart3 className="w-8 h-8 text-teal-600" />
              <h1 className="text-2xl font-bold text-gray-900 font-bubble">{t('statistics')}</h1>
            </div>
            <p className="text-gray-600">{t('analyzePerformance')}</p>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            {statCards.map((card, index) => (
              <motion.div
                key={card.title}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-white rounded-2xl p-6 shadow-sm border border-gray-200"
              >
                <div className="flex items-center justify-between mb-4">
                  <div className={`w-12 h-12 ${card.color} rounded-xl flex items-center justify-center`}>
                    <card.icon className="w-6 h-6 text-white" />
                  </div>
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-1">{card.value}</h3>
                <p className="text-gray-600 text-sm">{card.title}</p>
              </motion.div>
            ))}
          </div>

          {/* Pie Chart */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-white rounded-2xl p-6 shadow-sm border border-gray-200 mb-8"
          >
            <ReactECharts
              option={agentChartOptions}
              style={{ height: '400px' }}
              opts={{ renderer: 'canvas' }}
            />
          </motion.div>

          {/* Agent Details */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="bg-white rounded-2xl p-6 shadow-sm border border-gray-200 mb-10"
          >
            <h2 className="text-lg font-semibold text-gray-900 mb-4">{t('detailsByAgent')}</h2>
            <div className="space-y-4">
              {Object.entries(stats.agentStats || {}).map(([key, agent]) => {
                const agentData = agents[key];
                const agentColor = agentData?.color || 'bg-gray-500';
                if (!agent || !agentData) return null;
                
                return (
                  <div key={key} className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
                    <div className="flex items-center space-x-3">
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center ${agentColor}`}>
                        <MessageSquare className="w-5 h-5 text-white" />
                      </div>
                      <div>
                        <h3 className="font-medium text-gray-900">{agentData.name || agent.name}</h3>
                        <p className="text-sm text-gray-600">{agent.count || 0} {t('interactions')}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="w-32 bg-gray-200 rounded-full h-2">
                        <div 
                          className={`h-2 rounded-full ${
                            agentColor === 'bg-teal-500' ? 'bg-teal-500' :
                            agentColor === 'bg-yellow-500' ? 'bg-yellow-500' :
                            agentColor === 'bg-green-500' ? 'bg-green-500' :
                            agentColor === 'bg-blue-500' ? 'bg-blue-500' :
                            agentColor === 'bg-red-500' ? 'bg-red-500' :
                            agentColor === 'bg-purple-500' ? 'bg-purple-500' :
                            agentColor === 'bg-pink-500' ? 'bg-pink-500' :
                            'bg-gray-500'
                          }`}
                          style={{
                            width: `${Math.min(((agent.count || 0) / Math.max(stats.totalInteractions || 1, 1)) * 100, 100)}%`
                          }}
                        />
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default Statistics;