import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useApp } from '../contexts/AppContext';
import { X, Check, Bot, MessageCircle, Settings, BarChart3, BookOpen, Save, AlertCircle, Shield, Loader, TestTube, ExternalLink } from 'lucide-react';

const AgentEditModal = () => {
  const { 
    editingAgent, 
    setEditingAgent, 
    agents, 
    updateAgent, 
    t, 
    updateWebhookUrl, 
    testWebhook, 
    webhookUrls,
    generateApiKey,
    rotateApiKey,
    getAgentApiKey,
    getAgentResponseUrl
  } = useApp();
  
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    color: 'bg-teal-500',
    icon: 'MessageCircle',
    webhook: ''
  });
  
  const [testingWebhook, setTestingWebhook] = useState(false);
  const [testResult, setTestResult] = useState(null);
  const [apiKey, setApiKey] = useState('');
  const [responseUrl, setResponseUrl] = useState('');
  const [isRegeneratingKey, setIsRegeneratingKey] = useState(false);
  const [activeTab, setActiveTab] = useState('general');

  // Available colors 
  const colorOptions = [
    { name: 'Teal', value: 'bg-teal-500' },
    { name: 'Yellow', value: 'bg-yellow-500' },
    { name: 'Green', value: 'bg-green-500' },
    { name: 'Blue', value: 'bg-blue-500' },
    { name: 'Red', value: 'bg-red-500' },
    { name: 'Purple', value: 'bg-purple-500' },
    { name: 'Pink', value: 'bg-pink-500' },
    { name: 'Gray', value: 'bg-gray-500' }
  ];

  // Available icons
  const iconOptions = [
    { name: 'Message', value: 'MessageCircle' },
    { name: 'Robot', value: 'Bot' },
    { name: 'Settings', value: 'Settings' },
    { name: 'Chart', value: 'BarChart3' },
    { name: 'Book', value: 'BookOpen' }
  ];

  useEffect(() => {
    if (editingAgent && agents[editingAgent]) {
      setFormData({
        name: agents[editingAgent].name || '',
        description: agents[editingAgent].description || '',
        color: agents[editingAgent].color || 'bg-teal-500',
        icon: agents[editingAgent].icon || 'MessageCircle',
        webhook: webhookUrls[editingAgent] || ''
      });
      
      // Fetch API key and response URL
      const fetchApiData = async () => {
        try {
          const key = await getAgentApiKey(editingAgent);
          const url = getAgentResponseUrl(editingAgent);
          setApiKey(key || '');
          setResponseUrl(url || '');
        } catch (error) {
          console.error('Error fetching API data:', error);
        }
      };
      
      fetchApiData();
    }
  }, [editingAgent, agents, webhookUrls, getAgentApiKey, getAgentResponseUrl]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleTestWebhook = async () => {
    if (!formData.webhook.trim()) return;
    
    setTestingWebhook(true);
    setTestResult(null);
    
    // Temporarily update webhook URL for testing
    updateWebhookUrl(editingAgent, formData.webhook);
    
    try {
      const result = await testWebhook(editingAgent);
      setTestResult(result ? 'success' : 'error');
    } catch (error) {
      setTestResult('error');
    } finally {
      setTestingWebhook(false);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (editingAgent) {
      // Update agent data
      updateAgent(editingAgent, {
        name: formData.name,
        description: formData.description,
        color: formData.color,
        icon: formData.icon
      });
      
      // Update webhook URL
      updateWebhookUrl(editingAgent, formData.webhook);
      
      setEditingAgent(null);
    }
  };

  const handleRegenerateApiKey = async () => {
    if (!editingAgent) return;
    
    if (window.confirm(t('confirmRegenerateKey'))) {
      setIsRegeneratingKey(true);
      try {
        const newKey = await rotateApiKey(editingAgent);
        setApiKey(newKey);
        alert(t('keyRegenerated'));
      } catch (error) {
        console.error('Error regenerating API key:', error);
        alert(t('keyRegenerationError'));
      } finally {
        setIsRegeneratingKey(false);
      }
    }
  };

  const getIconComponent = (iconName) => {
    switch (iconName) {
      case 'Bot': return Bot;
      case 'MessageCircle': return MessageCircle;
      case 'Settings': return Settings;
      case 'BarChart3': return BarChart3;
      case 'BookOpen': return BookOpen;
      default: return MessageCircle;
    }
  };

  if (!editingAgent) return null;

  return (
    <AnimatePresence>
      {editingAgent && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4"
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            className="bg-white rounded-2xl shadow-xl w-full max-w-md overflow-hidden max-h-[90vh] overflow-y-auto"
          >
            <div className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-semibold text-gray-900">{t('editAgent')}</h2>
                <button
                  onClick={() => setEditingAgent(null)}
                  className="p-2 rounded-full hover:bg-gray-100 transition-colors"
                >
                  <X className="w-5 h-5 text-gray-500" />
                </button>
              </div>
              
              {/* Tabs */}
              <div className="flex space-x-2 mb-6 border-b border-gray-200">
                <button 
                  className={`px-4 py-2 font-medium ${activeTab === 'general' ? 'text-teal-600 border-b-2 border-teal-500' : 'text-gray-500 hover:text-gray-700'}`}
                  onClick={() => setActiveTab('general')}
                >
                  {t('general')}
                </button>
                <button 
                  className={`px-4 py-2 font-medium ${activeTab === 'api' ? 'text-teal-600 border-b-2 border-teal-500' : 'text-gray-500 hover:text-gray-700'}`}
                  onClick={() => setActiveTab('api')}
                >
                  API
                </button>
              </div>

              <form onSubmit={handleSubmit} className="space-y-4">
                {activeTab === 'general' ? (
                  <>
                    {/* Agent Name */}
                    <div>
                      <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                        {t('agentName')}
                      </label>
                      <input
                        type="text"
                        id="name"
                        name="name"
                        value={formData.name}
                        onChange={handleChange}
                        required
                        className="w-full px-4 py-2 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent"
                      />
                    </div>

                    {/* Agent Description */}
                    <div>
                      <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-1">
                        {t('agentDescription')}
                      </label>
                      <input
                        type="text"
                        id="description"
                        name="description"
                        value={formData.description}
                        onChange={handleChange}
                        className="w-full px-4 py-2 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent"
                      />
                    </div>

                    {/* Webhook URL */}
                    <div>
                      <label htmlFor="webhook" className="block text-sm font-medium text-gray-700 mb-1">
                        {t('webhookUrl')}
                      </label>
                      <input
                        type="url"
                        id="webhook"
                        name="webhook"
                        value={formData.webhook}
                        onChange={handleChange}
                        placeholder="https://webhook.site/your-webhook-url"
                        className="w-full px-4 py-2 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent"
                      />
                      {/* Test Webhook Button */}
                      {formData.webhook && (
                        <div className="mt-2 flex items-center space-x-2">
                          <motion.button
                            type="button"
                            whileHover={{ scale: 1.02 }}
                            whileTap={{ scale: 0.98 }}
                            onClick={handleTestWebhook}
                            disabled={testingWebhook}
                            className="px-3 py-1 bg-yellow-500 text-white rounded-lg hover:bg-yellow-600 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 flex items-center space-x-1 text-sm"
                          >
                            <TestTube className={`w-3 h-3 ${testingWebhook ? 'animate-spin' : ''}`} />
                            <span>{testingWebhook ? t('testing') : t('testConnection')}</span>
                          </motion.button>
                          {testResult && (
                            <motion.div
                              initial={{ opacity: 0, scale: 0.8 }}
                              animate={{ opacity: 1, scale: 1 }}
                              className={`flex items-center space-x-1 text-sm ${testResult === 'success' ? 'text-green-600' : 'text-red-600'}`}
                            >
                              <AlertCircle className="w-3 h-3" />
                              <span>{testResult === 'success' ? t('success') : t('failure')}</span>
                            </motion.div>
                          )}
                        </div>
                      )}
                    </div>

                    {/* Color Selection */}
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        {t('agentColor')}
                      </label>
                      <div className="grid grid-cols-4 gap-2">
                        {colorOptions.map((color) => (
                          <button
                            key={color.value}
                            type="button"
                            onClick={() => setFormData(prev => ({ ...prev, color: color.value }))}
                            className={`w-12 h-12 rounded-full ${color.value} flex items-center justify-center transition-transform ${
                              formData.color === color.value ? 'ring-4 ring-gray-300 scale-110' : ''
                            }`}
                          >
                            {formData.color === color.value && (
                              <Check className="w-5 h-5 text-white" />
                            )}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Icon Selection */}
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        {t('agentIcon')}
                      </label>
                      <div className="grid grid-cols-5 gap-2">
                        {iconOptions.map((icon) => {
                          const IconComponent = getIconComponent(icon.value);
                          return (
                            <button
                              key={icon.value}
                              type="button"
                              onClick={() => setFormData(prev => ({ ...prev, icon: icon.value }))}
                              className={`w-12 h-12 rounded-lg bg-gray-100 flex items-center justify-center transition-transform ${
                                formData.icon === icon.value ? 'ring-2 ring-teal-500 bg-teal-50 scale-105' : ''
                              }`}
                            >
                              <IconComponent className={`w-6 h-6 ${formData.icon === icon.value ? 'text-teal-500' : 'text-gray-500'}`} />
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  </>
                ) : (
                  <>
                    {/* API Tab */}
                    <div className="space-y-4">
                      {/* URL de réponse à copier */}
                      <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
                        <div className="flex items-center space-x-2 mb-3">
                          <ExternalLink className="w-5 h-5 text-blue-600" />
                          <h3 className="font-semibold text-blue-900">URL de Réponse</h3>
                        </div>
                        <p className="text-sm text-blue-800 mb-3">
                          Utilisez cette URL dans votre scénario Make.com ou n8n (module HTTP Request) :
                        </p>
                        <div className="bg-white border border-blue-200 rounded-lg p-3">
                          <code className="text-sm text-gray-800 break-all">
                            {responseUrl || 'Chargement...'}
                          </code>
                        </div>
                      </div>

                      {/* Clé API */}
                      <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-4">
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-center space-x-2">
                            <Shield className="w-5 h-5 text-yellow-600" />
                            <h3 className="font-semibold text-yellow-900">Clé API (Sécurité)</h3>
                          </div>
                          <button
                            type="button"
                            onClick={handleRegenerateApiKey}
                            disabled={isRegeneratingKey}
                            className="px-2 py-1 bg-yellow-500 text-white rounded-lg text-xs hover:bg-yellow-600 disabled:opacity-50 flex items-center space-x-1"
                          >
                            {isRegeneratingKey ? <Loader className="w-3 h-3 animate-spin" /> : null}
                            <span>Régénérer</span>
                          </button>
                        </div>
                        <p className="text-sm text-yellow-800 mb-3">
                          Ajoutez ce header dans votre requête HTTP :
                        </p>
                        <div className="bg-white border border-yellow-200 rounded-lg p-3">
                          <code className="text-sm text-gray-800 break-all">
                            Authorization: Bearer {apiKey || 'Chargement...'}
                          </code>
                        </div>
                      </div>

                      {/* Instructions */}
                      <div className="bg-gray-50 rounded-xl p-4">
                        <h3 className="font-semibold text-gray-900 mb-3">Instructions</h3>
                        <div className="space-y-2 text-sm text-gray-700">
                          <div className="flex items-start space-x-2">
                            <span className="bg-teal-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs font-bold">1</span>
                            <span>Copiez l'URL de réponse ci-dessus</span>
                          </div>
                          <div className="flex items-start space-x-2">
                            <span className="bg-teal-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs font-bold">2</span>
                            <span>Dans votre scénario Make/n8n, ajoutez un module HTTP Request</span>
                          </div>
                          <div className="flex items-start space-x-2">
                            <span className="bg-teal-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs font-bold">3</span>
                            <span>Collez l'URL et ajoutez le header Authorization</span>
                          </div>
                          <div className="flex items-start space-x-2">
                            <span className="bg-teal-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs font-bold">4</span>
                            <span>Votre agent est prêt à recevoir et répondre aux messages !</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </>
                )}

                {/* Preview */}
                <div className="p-4 bg-gray-100 rounded-xl">
                  <p className="text-sm font-medium text-gray-700 mb-2">{t('preview')}</p>
                  <div className="flex items-center space-x-3">
                    <div className={`w-10 h-10 ${formData.color} rounded-full flex items-center justify-center`}>
                      {React.createElement(getIconComponent(formData.icon), { className: "w-5 h-5 text-white" })}
                    </div>
                    <div>
                      <p className="font-medium text-gray-900">{formData.name}</p>
                      <p className="text-xs text-gray-500">{formData.description}</p>
                    </div>
                  </div>
                </div>

                {/* Submit Button */}
                <div className="flex justify-end pt-4">
                  <button
                    type="button"
                    onClick={() => setEditingAgent(null)}
                    className="px-4 py-2 text-gray-700 bg-gray-100 rounded-lg mr-2 hover:bg-gray-200 transition-colors"
                  >
                    {t('cancel')}
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-teal-500 text-white rounded-lg hover:bg-teal-600 transition-colors"
                  >
                    {t('save')}
                  </button>
                </div>
              </form>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default AgentEditModal;