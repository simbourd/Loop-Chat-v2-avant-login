import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useApp } from '../contexts/AppContext';
import { BookOpen, ChevronRight, ChevronLeft, Play } from 'lucide-react';

const Tutorial = () => {
  const { t, language } = useApp();
  const [currentStep, setCurrentStep] = useState(0);

  const tutorialSteps = language === 'fr' ? [
    {
      title: 'Bienvenue dans Loop Chat',
      content: 'Loop Chat est votre plateforme collaborative pour interagir avec plusieurs agents IA spécialisés.',
      image: '🤖',
      tips: [
        'Chaque agent IA a sa propre spécialité',
        'Le canal général distribue automatiquement vos requêtes',
        'Tous vos chats sont sauvegardés et accessibles'
      ]
    },
    {
      title: 'Ajouter et Gérer des Agents',
      content: 'Créez facilement de nouveaux agents personnalisés pour vos besoins spécifiques.',
      image: '➕',
      tips: [
        'Cliquez sur le bouton "+" pour ajouter un agent',
        'Personnalisez le nom, la couleur et l\'icône',
        'Supprimez les agents dont vous n\'avez plus besoin'
      ]
    },
    {
      title: 'Navigation et Interface',
      content: 'Utilisez la barre latérale pour naviguer entre vos différents chats et accéder aux fonctionnalités.',
      image: '🧭',
      tips: [
        'Cliquez sur un chat pour l\'ouvrir',
        'Le menu burger (☰) ouvre/ferme la sidebar sur mobile',
        'Les points verts indiquent les agents connectés'
      ]
    },
    {
      title: 'Canal Général et IA Manager',
      content: 'Le canal général utilise un IA Manager qui distribue vos requêtes vers le bon agent spécialisé.',
      image: '🎯',
      tips: [
        'Posez vos questions en langage naturel',
        'L\'IA Manager analyse votre demande',
        'Votre requête est automatiquement routée vers le bon expert'
      ]
    },
    {
      title: 'Configuration du Webhook',
      content: 'Connectez votre webhook (n8n, Make.com) pour activer l\'IA Manager du canal général.',
      image: '🔗',
      tips: [
        'Allez dans Paramètres > URL du Webhook',
        'Collez votre URL de webhook',
        'Testez la connexion avant utilisation'
      ]
    },
    {
      title: 'Statistiques et Suivi',
      content: 'Analysez vos interactions et optimisez votre utilisation des agents IA.',
      image: '📊',
      tips: [
        'Consultez vos statistiques d\'utilisation',
        'Identifiez les agents les plus sollicités',
        'Suivez l\'évolution de vos interactions'
      ]
    }
  ] : [
    {
      title: 'Welcome to Loop Chat',
      content: 'Loop Chat is your collaborative platform for interacting with multiple specialized AI agents.',
      image: '🤖',
      tips: [
        'Each AI agent has its own specialty',
        'The general channel automatically distributes your queries',
        'All your chats are saved and accessible'
      ]
    },
    {
      title: 'Adding and Managing Agents',
      content: 'Easily create new custom agents for your specific needs.',
      image: '➕',
      tips: [
        'Click the "+" button to add an agent',
        'Customize the name, color and icon',
        'Delete agents you no longer need'
      ]
    },
    {
      title: 'Navigation and Interface',
      content: 'Use the sidebar to navigate between your different chats and access features.',
      image: '🧭',
      tips: [
        'Click on a chat to open it',
        'The burger menu (☰) opens/closes the sidebar on mobile',
        'Green dots indicate connected agents'
      ]
    },
    {
      title: 'General Channel and AI Manager',
      content: 'The general channel uses an AI Manager that distributes your queries to the right specialized agent.',
      image: '🎯',
      tips: [
        'Ask your questions in natural language',
        'The AI Manager analyzes your request',
        'Your query is automatically routed to the right expert'
      ]
    },
    {
      title: 'Webhook Configuration',
      content: 'Connect your webhook (n8n, Make.com) to activate the AI Manager of the general channel.',
      image: '🔗',
      tips: [
        'Go to Settings > Webhook URL',
        'Paste your webhook URL',
        'Test the connection before use'
      ]
    },
    {
      title: 'Statistics and Tracking',
      content: 'Analyze your interactions and optimize your use of AI agents.',
      image: '📊',
      tips: [
        'Check your usage statistics',
        'Identify the most requested agents',
        'Track the evolution of your interactions'
      ]
    }
  ];

  const nextStep = () => {
    if (currentStep < tutorialSteps.length - 1) {
      setCurrentStep(currentStep + 1);
    }
  };

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const goToStep = (step) => {
    setCurrentStep(step);
  };

  return (
    <div className="flex-1 overflow-hidden flex flex-col h-full">
      <div className="flex-1 overflow-y-auto">
        <div className="p-6 max-w-4xl mx-auto pb-20">
          {/* Header */}
          <div className="mb-8">
            <div className="flex items-center space-x-3 mb-2">
              <BookOpen className="w-8 h-8 text-teal-600" />
              <h1 className="text-2xl font-bold text-gray-900 font-bubble">{t('tutorial')}</h1>
            </div>
            <p className="text-gray-600">{t('learnToUse')}</p>
          </div>

          {/* Progress Bar */}
          <div className="mb-8">
            <div className="flex items-center justify-between mb-4">
              <span className="text-sm font-medium text-gray-700">
                {t('step')} {currentStep + 1} {t('on')} {tutorialSteps.length}
              </span>
              <span className="text-sm text-gray-500">
                {Math.round(((currentStep + 1) / tutorialSteps.length) * 100)}{t('completed')}
              </span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <motion.div
                className="bg-teal-500 h-2 rounded-full"
                initial={{ width: 0 }}
                animate={{ width: `${((currentStep + 1) / tutorialSteps.length) * 100}%` }}
                transition={{ duration: 0.5 }}
              />
            </div>
          </div>

          {/* Tutorial Content */}
          <div className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden mb-8">
            <AnimatePresence mode="wait">
              <motion.div
                key={currentStep}
                initial={{ opacity: 0, x: 50 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -50 }}
                transition={{ duration: 0.3 }}
                className="p-8"
              >
                {/* Step Content */}
                <div className="text-center mb-8">
                  <div className="text-6xl mb-4">{tutorialSteps[currentStep].image}</div>
                  <h2 className="text-2xl font-bold text-gray-900 mb-4">
                    {tutorialSteps[currentStep].title}
                  </h2>
                  <p className="text-gray-600 text-lg leading-relaxed">
                    {tutorialSteps[currentStep].content}
                  </p>
                </div>

                {/* Tips */}
                <div className="bg-teal-50 rounded-xl p-6 mb-8">
                  <h3 className="text-lg font-semibold text-teal-900 mb-4">💡 {t('practicalTips')}</h3>
                  <ul className="space-y-2">
                    {tutorialSteps[currentStep].tips.map((tip, index) => (
                      <li key={index} className="flex items-start space-x-2 text-teal-800">
                        <span className="text-teal-500 mt-1">•</span>
                        <span>{tip}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </motion.div>
            </AnimatePresence>

            {/* Navigation */}
            <div className="bg-gray-50 px-8 py-6 flex items-center justify-between">
              <button
                onClick={prevStep}
                disabled={currentStep === 0}
                className="flex items-center space-x-2 px-4 py-2 text-gray-600 hover:text-gray-900 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                <ChevronLeft className="w-4 h-4" />
                <span>{t('previous')}</span>
              </button>

              {/* Step Indicators */}
              <div className="flex space-x-2">
                {tutorialSteps.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => goToStep(index)}
                    className={`w-3 h-3 rounded-full transition-colors ${
                      index === currentStep ? 'bg-teal-500' : 'bg-gray-300'
                    }`}
                  />
                ))}
              </div>

              <button
                onClick={nextStep}
                disabled={currentStep === tutorialSteps.length - 1}
                className="flex items-center space-x-2 px-4 py-2 bg-teal-500 text-white rounded-lg hover:bg-teal-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                <span>{t('next')}</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-10">
            <motion.div
              whileHover={{ scale: 1.02 }}
              className="bg-white rounded-xl p-6 shadow-sm border border-gray-200 text-center cursor-pointer"
            >
              <div className="text-2xl mb-2">🚀</div>
              <h3 className="font-semibold text-gray-900 mb-2">{t('quickStart')}</h3>
              <p className="text-sm text-gray-600">{t('quickStartDesc')}</p>
            </motion.div>
            <motion.div
              whileHover={{ scale: 1.02 }}
              className="bg-white rounded-xl p-6 shadow-sm border border-gray-200 text-center cursor-pointer"
            >
              <div className="text-2xl mb-2">⚙️</div>
              <h3 className="font-semibold text-gray-900 mb-2">{t('configuration')}</h3>
              <p className="text-sm text-gray-600">{t('configurationDesc')}</p>
            </motion.div>
            <motion.div
              whileHover={{ scale: 1.02 }}
              className="bg-white rounded-xl p-6 shadow-sm border border-gray-200 text-center cursor-pointer"
            >
              <div className="text-2xl mb-2">📈</div>
              <h3 className="font-semibold text-gray-900 mb-2">{t('statistics')}</h3>
              <p className="text-sm text-gray-600">{t('statisticsDesc')}</p>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Tutorial;