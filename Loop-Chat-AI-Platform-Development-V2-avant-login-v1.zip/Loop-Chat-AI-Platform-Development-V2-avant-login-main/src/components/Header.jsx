import React from 'react';
import { motion } from 'framer-motion';
import { useApp } from '../contexts/AppContext';
import { Menu, Settings, BarChart3, BookOpen } from 'lucide-react';

const Header = () => {
  const { isSidebarOpen, setIsSidebarOpen, t, activeChat, setActiveChat } = useApp();

  // Menu items for the mobile header
  const menuItems = [
    { id: 'settings', name: t('settings'), icon: Settings },
    { id: 'statistics', name: t('statistics'), icon: BarChart3 },
    { id: 'tutorial', name: t('tutorial'), icon: BookOpen }
  ];

  return (
    <motion.header
      initial={{ y: -50, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      className="bg-white shadow-sm border-b border-gray-200 px-4 py-3 lg:hidden"
    >
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setIsSidebarOpen(!isSidebarOpen)}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <Menu className="w-6 h-6 text-gray-700" />
          </motion.button>
          <h1 className="text-xl font-bold text-gray-900 font-bubble">{t('appTitle')}</h1>
        </div>
        
        {/* Mobile menu icons */}
        <div className="flex items-center space-x-3">
          {menuItems.map((item) => (
            <motion.button
              key={item.id}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setActiveChat(item.id)}
              className={`p-2 rounded-full transition-all ${
                activeChat === item.id 
                  ? 'bg-teal-100 text-teal-600' 
                  : 'hover:bg-gray-100 text-gray-600'
              }`}
              title={item.name}
            >
              <item.icon className="w-5 h-5" />
            </motion.button>
          ))}
        </div>
      </div>
    </motion.header>
  );
};

export default Header;