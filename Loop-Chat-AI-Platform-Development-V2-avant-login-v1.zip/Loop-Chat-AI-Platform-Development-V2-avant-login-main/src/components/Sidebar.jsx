import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useApp } from '../contexts/AppContext';
import { Bot, MessageCircle, Settings, BarChart3, BookOpen, MoreHorizontal, Edit, Trash2, Link, Plus, MessageSquare, PlusCircle, Zap } from 'lucide-react';
import AgentEditModal from './AgentEditModal';
import AgentOnboarding from './AgentOnboarding';

const Sidebar = () => {
  const { 
    isSidebarOpen, 
    setIsSidebarOpen, 
    activeChat, 
    setActiveChat, 
    t, 
    isWebhookConnected, 
    agents, 
    setEditingAgent, 
    webhookUrls, 
    addAgent, 
    deleteAgent, 
    messages, 
    deleteConversation, 
    conversations, 
    createConversation 
  } = useApp();
  
  const [showMenu, setShowMenu] = useState(null);
  const [showAgentsMenu, setShowAgentsMenu] = useState(true);
  const [showChatsMenu, setShowChatsMenu] = useState(true);
  const [showOnboarding, setShowOnboarding] = useState(false);
  const menuRef = useRef(null);

  // Close menu when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (menuRef.current && !menuRef.current.contains(event.target)) {
        setShowMenu(null);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  // Prepare agents list
  const agentsList = Object.keys(agents).map(agentId => ({
    id: agentId,
    name: agents[agentId].name,
    icon: agents[agentId].icon || (agentId === 'general' ? 'Bot' : 'MessageCircle'),
    description: agents[agentId].description || '',
    color: agents[agentId].color || 'bg-gray-500',
    isConnected: isWebhookConnected[agentId] && webhookUrls[agentId],
    isDefault: agents[agentId].isDefault
  }));

  // Get all conversations
  const allConversations = Object.entries(conversations).map(([conversationId, conversation]) => {
    const associatedAgent = agents[conversation.agentId];
    return {
      id: conversationId,
      title: conversation.title,
      agentId: conversation.agentId,
      agentName: associatedAgent?.name || 'Agent inconnu',
      agentIcon: associatedAgent?.icon || 'MessageCircle',
      agentColor: associatedAgent?.color || 'bg-gray-500',
      timestamp: conversation.lastUpdated || new Date(),
      messageCount: messages[conversationId]?.length || 0
    };
  }).sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));

  const menuItems = [
    { id: 'settings', name: t('settings'), icon: Settings },
    { id: 'statistics', name: t('statistics'), icon: BarChart3 },
    { id: 'tutorial', name: t('tutorial'), icon: BookOpen }
  ];

  const sidebarVariants = {
    open: { x: 0, opacity: 1 },
    closed: { x: -300, opacity: 0 }
  };

  const handleEditAgent = (agentId) => {
    setEditingAgent(agentId);
    setShowMenu(null);
  };

  const handleAddAgent = async () => {
    setShowOnboarding(true);
    setShowMenu(null);
  };

  const handleAgentCreated = (agentData) => {
    // L'agent a été créé via l'onboarding
    // Recharger les données ou mettre à jour l'état
    console.log('Agent créé via onboarding:', agentData);
  };

  const handleDeleteAgent = (agentId) => {
    if (window.confirm(t('confirmDelete'))) {
      deleteAgent(agentId);
    }
    setShowMenu(null);
  };

  const handleDeleteConversation = (e, conversationId) => {
    e.stopPropagation();
    if (window.confirm(t('confirmDeleteConversation'))) {
      deleteConversation(conversationId);
    }
  };

  const handleCreateConversation = (agentId) => {
    const newConversationId = createConversation(agentId);
    setActiveChat(newConversationId);
    setShowMenu(null);
  };

  const getIconComponent = (iconName) => {
    switch (iconName) {
      case 'Bot': return Bot;
      case 'MessageCircle': return MessageCircle;
      case 'Settings': return Settings;
      case 'BarChart3': return BarChart3;
      case 'BookOpen': return BookOpen;
      default: return MessageCircle;
    }
  };

  const toggleMenu = (e, agentId) => {
    e.stopPropagation();
    e.preventDefault();
    setShowMenu(showMenu === agentId ? null : agentId);
  };

  const toggleAgentsMenu = () => {
    setShowAgentsMenu(!showAgentsMenu);
  };

  const toggleChatsMenu = () => {
    setShowChatsMenu(!showChatsMenu);
  };

  return (
    <>
      {/* Mobile overlay */}
      <AnimatePresence>
        {isSidebarOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden"
            onClick={() => setIsSidebarOpen(false)}
          />
        )}
      </AnimatePresence>

      {/* Agent Edit Modal */}
      <AgentEditModal />

      {/* Agent Onboarding Modal */}
      <AgentOnboarding 
        isOpen={showOnboarding}
        onClose={() => setShowOnboarding(false)}
        onAgentCreated={handleAgentCreated}
      />

      {/* Sidebar */}
      <AnimatePresence>
        {isSidebarOpen && (
          <motion.div
            initial="closed"
            animate="open"
            exit="closed"
            variants={sidebarVariants}
            transition={{ type: "spring", stiffness: 300, damping: 30 }}
            className="fixed left-0 top-0 h-full w-80 bg-gray-900 text-white z-50 lg:relative lg:z-0 shadow-2xl flex flex-col"
          >
            {/* Header */}
            <div className="p-6 border-b border-gray-700 flex items-center justify-between flex-shrink-0">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-gradient-to-br from-teal-400 to-teal-600 rounded-full flex items-center justify-center">
                  <Bot className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h1 className="text-xl font-bold font-bubble">{t('appTitle')}</h1>
                  <p className="text-gray-400 text-sm">Collaborative AI</p>
                </div>
              </div>
              <button
                onClick={() => setIsSidebarOpen(false)}
                className="lg:hidden p-2 hover:bg-gray-800 rounded-lg transition-colors"
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>

            {/* Sidebar Content */}
            <div className="flex-1 overflow-y-auto p-4 space-y-6">
              {/* Conversations Section */}
              <div>
                <div className="flex items-center justify-between mb-3">
                  <button
                    onClick={toggleChatsMenu}
                    className="flex items-center space-x-2 text-sm font-semibold text-gray-400 uppercase tracking-wide hover:text-gray-300 transition-colors"
                  >
                    <MessageSquare className="w-4 h-4" />
                    <span>{t('conversations')}</span>
                    <motion.div
                      animate={{ rotate: showChatsMenu ? 180 : 0 }}
                      transition={{ duration: 0.2 }}
                    >
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                      </svg>
                    </motion.div>
                  </button>
                </div>

                <AnimatePresence>
                  {showChatsMenu && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      className="space-y-2"
                    >
                      {allConversations.length > 0 ? (
                        allConversations.map((conversation) => {
                          const IconComponent = getIconComponent(conversation.agentIcon);
                          return (
                            <motion.div
                              key={`chat-${conversation.id}`}
                              initial={{ opacity: 0, x: -20 }}
                              animate={{ opacity: 1, x: 0 }}
                              exit={{ opacity: 0, x: -20 }}
                              className={`p-3 rounded-xl cursor-pointer transition-all duration-200 group ${
                                activeChat === conversation.id
                                  ? 'bg-teal-600 shadow-lg'
                                  : 'hover:bg-gray-800'
                              }`}
                              onClick={() => setActiveChat(conversation.id)}
                            >
                              <div className="flex items-center space-x-3">
                                <div className={`w-8 h-8 ${conversation.agentColor} rounded-full flex items-center justify-center`}>
                                  <IconComponent className="w-4 h-4 text-white" />
                                </div>
                                <div className="flex-1 min-w-0">
                                  <p className="font-medium truncate">{conversation.title}</p>
                                  <p className="text-xs text-gray-400 truncate">
                                    {conversation.agentName}
                                  </p>
                                </div>
                                <button
                                  onClick={(e) => handleDeleteConversation(e, conversation.id)}
                                  className="p-1 opacity-0 group-hover:opacity-100 hover:bg-gray-700 rounded-full transition-opacity"
                                >
                                  <Trash2 className="w-4 h-4 text-red-400" />
                                </button>
                              </div>
                            </motion.div>
                          );
                        })
                      ) : (
                        <div className="text-center py-4 text-gray-500 text-sm border border-gray-800 rounded-lg">
                          {t('noConversations')}
                          <p className="mt-2">
                            {t('startConversationFromAgents')}
                          </p>
                        </div>
                      )}
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              {/* Agents Section */}
              <div>
                <div className="flex items-center justify-between mb-3">
                  <button
                    onClick={toggleAgentsMenu}
                    className="flex items-center space-x-2 text-sm font-semibold text-gray-400 uppercase tracking-wide hover:text-gray-300 transition-colors"
                  >
                    <Bot className="w-4 h-4" />
                    <span>{t('availableAgents')}</span>
                    <motion.div
                      animate={{ rotate: showAgentsMenu ? 180 : 0 }}
                      transition={{ duration: 0.2 }}
                    >
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                      </svg>
                    </motion.div>
                  </button>
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={handleAddAgent}
                    className="p-2 bg-gradient-to-r from-teal-500 to-teal-600 hover:from-teal-600 hover:to-teal-700 rounded-lg transition-all duration-200 shadow-lg"
                    title="Créer un Agent IA"
                  >
                    <Zap className="w-4 h-4 text-white" />
                  </motion.button>
                </div>

                <AnimatePresence>
                  {showAgentsMenu && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      className="space-y-2"
                    >
                      {agentsList.map((agent) => {
                        const IconComponent = getIconComponent(agent.icon);
                        return (
                          <motion.div
                            key={agent.id}
                            initial={{ opacity: 0, x: -20 }}
                            animate={{ opacity: 1, x: 0 }}
                            exit={{ opacity: 0, x: -20 }}
                            className="relative"
                          >
                            <div className="p-3 rounded-xl cursor-pointer transition-all duration-200 group hover:bg-gray-800">
                              <div className="flex items-center space-x-3">
                                <div className={`w-10 h-10 ${agent.color} rounded-full flex items-center justify-center relative`}>
                                  <IconComponent className="w-5 h-5 text-white" />
                                  {agent.isConnected && (
                                    <div className="absolute -top-1 -right-1 w-3 h-3 bg-green-400 rounded-full border-2 border-gray-900" />
                                  )}
                                </div>
                                <div className="flex-1 min-w-0">
                                  <p className="font-medium truncate">{agent.name}</p>
                                  <p className="text-xs text-gray-400 truncate">{agent.description}</p>
                                </div>
                                <div className="flex items-center space-x-2">
                                  <button
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      handleCreateConversation(agent.id);
                                    }}
                                    className="p-1 text-teal-400 hover:bg-gray-700 rounded-full transition-all"
                                    title={t('newConversation')}
                                  >
                                    <PlusCircle className="w-5 h-5" />
                                  </button>
                                  <button
                                    onClick={(e) => toggleMenu(e, agent.id)}
                                    className="p-1 hover:bg-gray-700 rounded-full transition-all"
                                  >
                                    <MoreHorizontal className="w-4 h-4" />
                                  </button>
                                </div>
                              </div>
                            </div>

                            {/* Agent Menu */}
                            <AnimatePresence>
                              {showMenu === agent.id && (
                                <motion.div
                                  ref={menuRef}
                                  initial={{ opacity: 0, scale: 0.95, y: -10 }}
                                  animate={{ opacity: 1, scale: 1, y: 0 }}
                                  exit={{ opacity: 0, scale: 0.95, y: -10 }}
                                  transition={{ duration: 0.15 }}
                                  className="absolute right-0 top-full mt-1 bg-gray-800 rounded-lg shadow-xl border border-gray-700 z-50 py-1 w-48"
                                  style={{ zIndex: 1000 }}
                                >
                                  <button
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      handleEditAgent(agent.id);
                                    }}
                                    className="w-full text-left px-4 py-2 hover:bg-gray-700 flex items-center space-x-2 transition-colors"
                                  >
                                    <Edit className="w-4 h-4" />
                                    <span>{t('editAgent')}</span>
                                  </button>
                                  <button
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      setActiveChat('settings');
                                      setShowMenu(null);
                                    }}
                                    className="w-full text-left px-4 py-2 hover:bg-gray-700 flex items-center space-x-2 transition-colors"
                                  >
                                    <Link className="w-4 h-4" />
                                    <span>{t('webhookSettings')}</span>
                                  </button>
                                  {!agent.isDefault && (
                                    <button
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        handleDeleteAgent(agent.id);
                                      }}
                                      className="w-full text-left px-4 py-2 hover:bg-gray-700 flex items-center space-x-2 text-red-400 transition-colors"
                                    >
                                      <Trash2 className="w-4 h-4" />
                                      <span>{t('deleteAgent')}</span>
                                    </button>
                                  )}
                                </motion.div>
                              )}
                            </AnimatePresence>
                          </motion.div>
                        );
                      })}
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </div>

            {/* Connection Status and Menu */}
            <div className="p-4 border-t border-gray-700 flex-shrink-0">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center space-x-2 text-sm">
                  <div className={`w-2 h-2 rounded-full ${
                    Object.values(isWebhookConnected).some(status => status) ? 'bg-green-400' : 'bg-red-400'
                  }`} />
                  <span className="text-gray-400">
                    {Object.values(isWebhookConnected).some(status => status) ? t('connected') : t('disconnected')}
                  </span>
                </div>
              </div>

              {/* Horizontal Menu Icons */}
              <div className="flex justify-center items-center space-x-4 mt-3">
                {menuItems.map((item) => (
                  <motion.button
                    key={item.id}
                    whileHover={{ scale: 1.15 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => setActiveChat(item.id)}
                    className={`p-3 rounded-full transition-all duration-200 ${
                      activeChat === item.id
                        ? 'bg-teal-600 shadow-lg'
                        : 'hover:bg-gray-800'
                    }`}
                    title={item.name}
                  >
                    <item.icon className="w-5 h-5" />
                  </motion.button>
                ))}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

export default Sidebar;