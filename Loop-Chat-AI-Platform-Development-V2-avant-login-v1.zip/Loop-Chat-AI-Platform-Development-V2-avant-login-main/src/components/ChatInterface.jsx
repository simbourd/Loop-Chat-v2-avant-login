import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useApp } from '../contexts/AppContext';
import { Send, Bot, User, AlertCircle } from 'lucide-react';
import { format } from 'date-fns';
import SafeIcon from '../common/SafeIcon';

const ChatInterface = () => {
  const { activeChat, messages, sendMessage, t, agents, isWebhookConnected, webhookUrls, conversations } = useApp();
  const [inputMessage, setInputMessage] = useState('');
  const messagesEndRef = useRef(null);
  const inputRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages[activeChat]]);

  const handleSend = () => {
    if (inputMessage.trim()) {
      sendMessage(activeChat, inputMessage.trim());
      setInputMessage('');
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const chatMessages = messages[activeChat] || [];

  // Determine which agent is associated with this chat
  const conversation = conversations[activeChat];
  const agentId = conversation?.agentId || activeChat;
  const currentAgent = agents[agentId] || {};

  // Function to get icon component
  const getIconComponent = (iconName) => {
    // This would be better with dynamic imports, but for simplicity:
    switch (iconName) {
      case 'Bot': return Bot;
      case 'MessageCircle':
      default: return Bot;
    }
  };

  const AgentIcon = getIconComponent(currentAgent.icon || 'Bot');

  const chatTitle = conversation?.title || currentAgent.name || t(activeChat === 'general' ? 'general' : 'marketingAgent');

  return (
    <div className="flex-1 flex flex-col h-full bg-gray-50 overflow-hidden">
      {/* Chat Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-4 shadow-sm flex-shrink-0">
        <div className="flex items-center space-x-3">
          <div className={`w-10 h-10 ${currentAgent.color || 'bg-teal-500'} rounded-full flex items-center justify-center`}>
            <AgentIcon className="w-6 h-6 text-white" />
          </div>
          <div>
            <h2 className="text-lg font-semibold text-gray-900">
              {chatTitle}
            </h2>
            <p className="text-sm text-gray-500">
              {currentAgent.description || (activeChat === 'general' ? t('aiManager') : t('specializedAgent'))}
            </p>
          </div>
          <div className="ml-auto">
            <div className="flex items-center space-x-2">
              <div className={`w-2 h-2 ${isWebhookConnected[agentId] && webhookUrls[agentId] ? 'bg-green-400 animate-pulse' : 'bg-red-400'} rounded-full`} />
              <span className="text-sm text-gray-500">
                {isWebhookConnected[agentId] && webhookUrls[agentId] ? t('online') : t('offline')}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-6 space-y-4">
        {chatMessages.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-gray-500">
            <AlertCircle className="w-12 h-12 mb-3 text-gray-300" />
            <p>{t('noMessages')}</p>
          </div>
        ) : (
          <AnimatePresence>
            {chatMessages.map((message) => (
              <motion.div
                key={message.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.3 }}
                className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div className={`flex items-start space-x-3 max-w-xs lg:max-w-md ${
                  message.sender === 'user' ? 'flex-row-reverse space-x-reverse' : ''
                }`}>
                  {/* Avatar */}
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                    message.sender === 'user' ? 'bg-blue-500' : currentAgent.color || 'bg-gradient-to-br from-teal-400 to-teal-600'
                  }`}>
                    {message.sender === 'user' ? (
                      <User className="w-4 h-4 text-white" />
                    ) : (
                      <AgentIcon className="w-4 h-4 text-white" />
                    )}
                  </div>

                  {/* Message Bubble */}
                  <div className={`p-4 rounded-2xl shadow-sm ${
                    message.sender === 'user' 
                      ? 'bg-blue-500 text-white rounded-br-md' 
                      : 'bg-white text-gray-900 rounded-bl-md border border-gray-200'
                  }`}>
                    <p className="text-sm font-bubble leading-relaxed">{message.content}</p>
                    <p className={`text-xs mt-2 ${
                      message.sender === 'user' ? 'text-blue-100' : 'text-gray-500'
                    }`}>
                      {format(new Date(message.timestamp), 'HH:mm')}
                    </p>
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Message Input */}
      <div className="bg-white border-t border-gray-200 p-4 flex-shrink-0">
        <div className="flex items-center space-x-3">
          <div className="flex-1 relative">
            <input
              ref={inputRef}
              type="text"
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder={t('typeMessage')}
              className="w-full px-4 py-3 bg-gray-100 border border-gray-300 rounded-full focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent font-bubble"
            />
          </div>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={handleSend}
            disabled={!inputMessage.trim()}
            className="p-3 bg-teal-500 text-white rounded-full hover:bg-teal-600 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 shadow-lg"
          >
            <Send className="w-5 h-5" />
          </motion.button>
        </div>
      </div>
    </div>
  );
};

export default ChatInterface;