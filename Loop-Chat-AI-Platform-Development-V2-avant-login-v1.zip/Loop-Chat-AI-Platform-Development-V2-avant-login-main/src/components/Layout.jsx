import React from 'react';
import { motion } from 'framer-motion';
import { useApp } from '../contexts/AppContext';
import Sidebar from './Sidebar';
import Header from './Header';
import ChatInterface from './ChatInterface';
import Settings from './Settings';
import Statistics from './Statistics';
import Tutorial from './Tutorial';

const Layout = () => {
  const { activeChat } = useApp();

  const renderMainContent = () => {
    switch (activeChat) {
      case 'settings':
        return <Settings />;
      case 'statistics':
        return <Statistics />;
      case 'tutorial':
        return <Tutorial />;
      default:
        return <ChatInterface />;
    }
  };

  return (
    <div className="h-screen bg-gray-50 flex overflow-hidden">
      <Sidebar />
      <div className="flex-1 flex flex-col min-w-0">
        <Header />
        <motion.main
          key={activeChat}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.3 }}
          className="flex-1 overflow-hidden"
        >
          {renderMainContent()}
        </motion.main>
      </div>
    </div>
  );
};

export default Layout;