import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useApp } from '../contexts/AppContext';
import { Check, Bot, Zap, Shield, ExternalLink, AlertCircle, Loader } from 'lucide-react';

const AgentOnboarding = ({ isOpen, onClose, onAgentCreated }) => {
  const { t } = useApp();
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    webhookUrlIn: '',
    color: 'bg-teal-500',
    icon: 'Bot'
  });
  const [generatedData, setGeneratedData] = useState(null);
  const [isCreating, setIsCreating] = useState(false);
  const [testingWebhook, setTestingWebhook] = useState(false);

  const colorOptions = [
    { name: 'Teal', value: 'bg-teal-500' },
    { name: 'Blue', value: 'bg-blue-500' },
    { name: 'Green', value: 'bg-green-500' },
    { name: 'Purple', value: 'bg-purple-500' },
    { name: 'Pink', value: 'bg-pink-500' },
    { name: 'Yellow', value: 'bg-yellow-500' },
    { name: 'Red', value: 'bg-red-500' },
    { name: 'Gray', value: 'bg-gray-500' }
  ];

  const iconOptions = [
    { name: 'Robot', value: 'Bot' },
    { name: 'Message', value: 'MessageCircle' },
    { name: 'Zap', value: 'Zap' },
    { name: 'Shield', value: 'Shield' }
  ];

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const generateApiKey = () => {
    return 'lc_' + Math.random().toString(36).substr(2, 32) + Date.now().toString(36);
  };

  const generateResponseUrl = (agentId) => {
    return `https://tvpisaticebdoxdrvdwa.supabase.co/functions/v1/webhook-response/${agentId}`;
  };

  const handleCreateAgent = async () => {
    setIsCreating(true);
    try {
      // Créer l'agent avec les données complètes
      const agentId = `agent_${Date.now()}`;
      const apiKey = generateApiKey();
      const responseUrl = generateResponseUrl(agentId);

      const agentData = {
        id: agentId,
        name: formData.name,
        description: formData.description,
        color: formData.color,
        icon: formData.icon,
        webhookUrlIn: formData.webhookUrlIn,
        webhookUrlOut: responseUrl,
        apiKey: apiKey,
        isActive: true,
        isDefault: false
      };

      // Sauvegarder dans Supabase
      await fetch(`https://tvpisaticebdoxdrvdwa.supabase.co/rest/v1/agents_loopchat_2024`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'apikey': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InR2cGlzYXRpY2ViZG94ZHJ2ZHdhIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTE1OTE2MjEsImV4cCI6MjA2NzE2NzYyMX0.n1NoEHQwpTnA0j3a-o5qUkITLo9f4iouEDogCUAHh44',
          'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InR2cGlzYXRpY2ViZG94ZHJ2ZHdhIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTE1OTE2MjEsImV4cCI6MjA2NzE2NzYyMX0.n1NoEHQwpTnA0j3a-o5qUkITLo9f4iouEDogCUAHh44'
        },
        body: JSON.stringify({
          agent_id: agentId,
          name: formData.name,
          description: formData.description,
          color: formData.color,
          icon: formData.icon,
          webhook_url_in: formData.webhookUrlIn,
          webhook_url_out: responseUrl,
          api_key: apiKey,
          is_active: true,
          is_default: false
        })
      });

      // Créer l'entrée dans la table des clés API
      await fetch(`https://tvpisaticebdoxdrvdwa.supabase.co/rest/v1/api_keys_loopchat_2024`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'apikey': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InR2cGlzYXRpY2ViZG94ZHJ2ZHdhIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTE1OTE2MjEsImV4cCI6MjA2NzE2NzYyMX0.n1NoEHQwpTnA0j3a-o5qUkITLo9f4iouEDogCUAHh44',
          'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InR2cGlzYXRpY2ViZG94ZHJ2ZHdhIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTE1OTE2MjEsImV4cCI6MjA2NzE2NzYyMX0.n1NoEHQwpTnA0j3a-o5qUkITLo9f4iouEDogCUAHh44'
        },
        body: JSON.stringify({
          agent_id: agentId,
          api_key: apiKey,
          is_active: true
        })
      });

      setGeneratedData({
        agentId,
        apiKey,
        responseUrl,
        agentData
      });

      setStep(2);

      // Notifier le parent
      if (onAgentCreated) {
        onAgentCreated(agentData);
      }
    } catch (error) {
      console.error('Erreur lors de la création de l\'agent:', error);
      alert('Erreur lors de la création de l\'agent. Veuillez réessayer.');
    } finally {
      setIsCreating(false);
    }
  };

  const testWebhookConnection = async () => {
    setTestingWebhook(true);
    try {
      const response = await fetch(formData.webhookUrlIn, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          test: true,
          message: 'Test de connexion Loop Chat',
          timestamp: new Date().toISOString()
        })
      });

      if (response.ok) {
        alert('✅ Connexion webhook réussie !');
      } else {
        alert('⚠️ Webhook accessible mais réponse inattendue');
      }
    } catch (error) {
      alert('❌ Erreur de connexion au webhook');
    } finally {
      setTestingWebhook(false);
    }
  };

  const resetForm = () => {
    setStep(1);
    setFormData({
      name: '',
      description: '',
      webhookUrlIn: '',
      color: 'bg-teal-500',
      icon: 'Bot'
    });
    setGeneratedData(null);
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4"
      >
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto"
        >
          {/* Header */}
          <div className="p-6 border-b border-gray-200">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-gradient-to-br from-teal-400 to-teal-600 rounded-xl flex items-center justify-center">
                  <Bot className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h2 className="text-2xl font-bold">
                    {step === 1 ? 'Créer un Agent IA' : 'Agent Créé avec Succès !'}
                  </h2>
                  <p className="text-gray-600">
                    {step === 1 ? 'Configuration ultra-simple en 2 minutes' : 'Utilisez les informations ci-dessous dans votre scénario'}
                  </p>
                </div>
              </div>
              <button
                onClick={onClose}
                className="p-2 hover:bg-gray-100 rounded-full transition-colors"
              >
                <svg className="w-6 h-6 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
          </div>

          <div className="p-6">
            {step === 1 ? (
              /* Étape 1: Configuration */
              <div className="space-y-6">
                {/* Nom de l'agent */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Nom de l'agent *
                  </label>
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                    placeholder="ex: Agent Marketing, Support Client..."
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent"
                    required
                  />
                </div>

                {/* Description */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Description (optionnel)
                  </label>
                  <input
                    type="text"
                    name="description"
                    value={formData.description}
                    onChange={handleInputChange}
                    placeholder="Décrivez brièvement le rôle de cet agent..."
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent"
                  />
                </div>

                {/* URL Webhook entrant */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    URL Webhook (Make.com / n8n) *
                  </label>
                  <div className="relative">
                    <input
                      type="url"
                      name="webhookUrlIn"
                      value={formData.webhookUrlIn}
                      onChange={handleInputChange}
                      placeholder="https://hook.eu1.make.com/..."
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent pr-20"
                      required
                    />
                    {formData.webhookUrlIn && (
                      <button
                        onClick={testWebhookConnection}
                        disabled={testingWebhook}
                        className="absolute right-2 top-2 px-3 py-1 bg-green-500 text-white rounded-lg hover:bg-green-600 disabled:opacity-50 text-sm flex items-center space-x-1"
                      >
                        {testingWebhook ? (
                          <Loader className="w-3 h-3 animate-spin" />
                        ) : (
                          <Zap className="w-3 h-3" />
                        )}
                        <span>Test</span>
                      </button>
                    )}
                  </div>
                  <p className="text-xs text-gray-500 mt-1">
                    Cette URL recevra les messages des utilisateurs
                  </p>
                </div>

                {/* Couleur */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Couleur
                  </label>
                  <div className="grid grid-cols-4 gap-2">
                    {colorOptions.map((color) => (
                      <button
                        key={color.value}
                        type="button"
                        onClick={() => setFormData(prev => ({ ...prev, color: color.value }))}
                        className={`w-12 h-12 rounded-full ${color.value} flex items-center justify-center transition-transform ${
                          formData.color === color.value ? 'ring-4 ring-gray-300 scale-110' : ''
                        }`}
                      >
                        {formData.color === color.value && (
                          <Check className="w-5 h-5 text-white" />
                        )}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Icône */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Icône
                  </label>
                  <div className="grid grid-cols-4 gap-2">
                    {iconOptions.map((icon) => (
                      <button
                        key={icon.value}
                        type="button"
                        onClick={() => setFormData(prev => ({ ...prev, icon: icon.value }))}
                        className={`w-12 h-12 rounded-lg bg-gray-100 flex items-center justify-center transition-transform ${
                          formData.icon === icon.value ? 'ring-2 ring-teal-500 bg-teal-50 scale-105' : ''
                        }`}
                      >
                        {icon.value === 'Bot' && <Bot className="w-6 h-6 text-gray-600" />}
                        {icon.value === 'MessageCircle' && <svg className="w-6 h-6 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" /></svg>}
                        {icon.value === 'Zap' && <Zap className="w-6 h-6 text-gray-600" />}
                        {icon.value === 'Shield' && <Shield className="w-6 h-6 text-gray-600" />}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Aperçu */}
                <div className="p-4 bg-gray-50 rounded-xl">
                  <p className="text-sm font-medium text-gray-700 mb-2">Aperçu</p>
                  <div className="flex items-center space-x-3">
                    <div className={`w-10 h-10 ${formData.color} rounded-full flex items-center justify-center`}>
                      {formData.icon === 'Bot' && <Bot className="w-5 h-5 text-white" />}
                      {formData.icon === 'MessageCircle' && <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" /></svg>}
                      {formData.icon === 'Zap' && <Zap className="w-5 h-5 text-white" />}
                      {formData.icon === 'Shield' && <Shield className="w-5 h-5 text-white" />}
                    </div>
                    <div>
                      <p className="font-medium text-gray-900">{formData.name || 'Nom de l\'agent'}</p>
                      <p className="text-sm text-gray-500">{formData.description || 'Description'}</p>
                    </div>
                  </div>
                </div>

                {/* Bouton Créer */}
                <div className="flex justify-end pt-4">
                  <button
                    onClick={handleCreateAgent}
                    disabled={!formData.name || !formData.webhookUrlIn || isCreating}
                    className="px-6 py-3 bg-teal-500 text-white rounded-xl hover:bg-teal-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center space-x-2"
                  >
                    {isCreating ? (
                      <>
                        <Loader className="w-5 h-5 animate-spin" />
                        <span>Création...</span>
                      </>
                    ) : (
                      <>
                        <Bot className="w-5 h-5" />
                        <span>Créer l'Agent</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            ) : (
              /* Étape 2: Résultat */
              <div className="space-y-6">
                {/* Succès */}
                <div className="bg-green-50 border border-green-200 rounded-xl p-4">
                  <div className="flex items-center space-x-2">
                    <Check className="w-5 h-5 text-green-600" />
                    <span className="text-green-800 font-medium">Agent créé avec succès !</span>
                  </div>
                </div>

                {/* Informations de l'agent */}
                <div className="bg-gray-50 rounded-xl p-4">
                  <h3 className="font-semibold text-gray-900 mb-3">Informations de l'Agent</h3>
                  <div className="flex items-center space-x-3 mb-3">
                    <div className={`w-10 h-10 ${formData.color} rounded-full flex items-center justify-center`}>
                      {formData.icon === 'Bot' && <Bot className="w-5 h-5 text-white" />}
                      {formData.icon === 'MessageCircle' && <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" /></svg>}
                      {formData.icon === 'Zap' && <Zap className="w-5 h-5 text-white" />}
                      {formData.icon === 'Shield' && <Shield className="w-5 h-5 text-white" />}
                    </div>
                    <div>
                      <p className="font-medium text-gray-900">{formData.name}</p>
                      <p className="text-sm text-gray-500">{formData.description}</p>
                    </div>
                  </div>
                  <div className="text-sm text-gray-600">
                    <p><strong>ID:</strong> {generatedData?.agentId}</p>
                  </div>
                </div>

                {/* URL de réponse */}
                <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
                  <div className="flex items-center space-x-2 mb-3">
                    <ExternalLink className="w-5 h-5 text-blue-600" />
                    <h3 className="font-semibold text-blue-900">URL de Réponse</h3>
                  </div>
                  <p className="text-sm text-blue-800 mb-3">
                    Utilisez cette URL dans votre scénario Make.com ou n8n (module HTTP Request) :
                  </p>
                  <div className="bg-white border border-blue-200 rounded-lg p-3">
                    <code className="text-sm text-gray-800 break-all">
                      {generatedData?.responseUrl}
                    </code>
                  </div>
                </div>

                {/* Clé API */}
                <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-4">
                  <div className="flex items-center space-x-2 mb-3">
                    <Shield className="w-5 h-5 text-yellow-600" />
                    <h3 className="font-semibold text-yellow-900">Clé API (Sécurité)</h3>
                  </div>
                  <p className="text-sm text-yellow-800 mb-3">
                    Ajoutez ce header dans votre requête HTTP :
                  </p>
                  <div className="bg-white border border-yellow-200 rounded-lg p-3">
                    <code className="text-sm text-gray-800 break-all">
                      Authorization: Bearer {generatedData?.apiKey}
                    </code>
                  </div>
                </div>

                {/* Instructions */}
                <div className="bg-gray-50 rounded-xl p-4">
                  <h3 className="font-semibold text-gray-900 mb-3">Instructions</h3>
                  <div className="space-y-2 text-sm text-gray-700">
                    <div className="flex items-start space-x-2">
                      <span className="bg-teal-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs font-bold">1</span>
                      <span>Copiez l'URL de réponse ci-dessus</span>
                    </div>
                    <div className="flex items-start space-x-2">
                      <span className="bg-teal-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs font-bold">2</span>
                      <span>Dans votre scénario Make/n8n, ajoutez un module HTTP Request</span>
                    </div>
                    <div className="flex items-start space-x-2">
                      <span className="bg-teal-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs font-bold">3</span>
                      <span>Collez l'URL et ajoutez le header Authorization</span>
                    </div>
                    <div className="flex items-start space-x-2">
                      <span className="bg-teal-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs font-bold">4</span>
                      <span>Votre agent est prêt à recevoir et répondre aux messages !</span>
                    </div>
                  </div>
                </div>

                {/* Boutons */}
                <div className="flex justify-between pt-4">
                  <button
                    onClick={resetForm}
                    className="px-4 py-2 text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors"
                  >
                    Créer un autre agent
                  </button>
                  <button
                    onClick={onClose}
                    className="px-6 py-2 bg-teal-500 text-white rounded-lg hover:bg-teal-600 transition-colors"
                  >
                    Terminer
                  </button>
                </div>
              </div>
            )}
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
};

export default AgentOnboarding;