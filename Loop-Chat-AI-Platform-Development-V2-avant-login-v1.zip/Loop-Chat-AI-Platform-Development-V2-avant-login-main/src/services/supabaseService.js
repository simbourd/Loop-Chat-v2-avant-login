import supabase from '../lib/supabase'

// Agents Services
export const agentsService = {
  async getAll() {
    console.log('📖 Récupération de tous les agents depuis Supabase...')
    const { data, error } = await supabase
      .from('agents_loopchat_2024')
      .select('*')
      .order('created_at', { ascending: true })
    
    if (error) {
      console.error('❌ Erreur lors de la récupération des agents:', error)
      throw error
    }
    
    console.log('✅ Agents récupérés:', data)
    return data
  },

  async getById(agentId) {
    const { data, error } = await supabase
      .from('agents_loopchat_2024')
      .select('*')
      .eq('agent_id', agentId)
      .single()
    
    if (error) {
      console.error(`❌ Erreur lors de la récupération de l'agent ${agentId}:`, error)
      throw error
    }
    
    return data
  },

  async create(agent) {
    console.log('🆕 Création d\'un agent dans Supabase:', agent)
    
    const agentData = {
      agent_id: agent.id,
      name: agent.name,
      description: agent.description,
      color: agent.color,
      icon: agent.icon,
      is_default: agent.isDefault || false,
      webhook_url: agent.webhookUrl || '',
      webhook_url_in: agent.webhookUrlIn || '',
      webhook_url_out: agent.webhookUrlOut || '',
      api_key: agent.apiKey || '',
      is_connected: agent.isConnected || false,
      is_active: agent.isActive || true
    }
    
    console.log('📝 Données envoyées à Supabase:', agentData)
    
    const { data, error } = await supabase
      .from('agents_loopchat_2024')
      .insert([agentData])
      .select()
    
    if (error) {
      console.error('❌ Erreur lors de la création de l\'agent:', error)
      throw error
    }
    
    console.log('✅ Agent créé dans Supabase:', data[0])
    return data[0]
  },

  async update(agentId, updates) {
    console.log('🔄 Mise à jour de l\'agent dans Supabase:', agentId, updates)
    
    const updateData = {
      name: updates.name,
      description: updates.description,
      color: updates.color,
      icon: updates.icon,
      webhook_url: updates.webhookUrl,
      webhook_url_in: updates.webhookUrlIn,
      webhook_url_out: updates.webhookUrlOut,
      api_key: updates.apiKey,
      is_connected: updates.isConnected,
      is_active: updates.isActive,
      updated_at: new Date()
    }
    
    console.log('📝 Données de mise à jour envoyées:', updateData)
    
    const { data, error } = await supabase
      .from('agents_loopchat_2024')
      .update(updateData)
      .eq('agent_id', agentId)
      .select()
    
    if (error) {
      console.error('❌ Erreur lors de la mise à jour de l\'agent:', error)
      throw error
    }
    
    console.log('✅ Agent mis à jour dans Supabase:', data[0])
    return data[0]
  },

  async delete(agentId) {
    console.log('🗑️ Suppression de l\'agent dans Supabase:', agentId)
    
    const { error } = await supabase
      .from('agents_loopchat_2024')
      .delete()
      .eq('agent_id', agentId)
    
    if (error) {
      console.error('❌ Erreur lors de la suppression de l\'agent:', error)
      throw error
    }
    
    console.log('✅ Agent supprimé de Supabase')
    return true
  }
}

// API Keys Services
export const apiKeysService = {
  async getByAgent(agentId) {
    const { data, error } = await supabase
      .from('api_keys_loopchat_2024')
      .select('*')
      .eq('agent_id', agentId)
      .eq('is_active', true)
      .single()
    
    if (error && error.code !== 'PGRST116') throw error
    return data
  },

  async create(agentId, apiKey) {
    const { data, error } = await supabase
      .from('api_keys_loopchat_2024')
      .insert([{
        agent_id: agentId,
        api_key: apiKey,
        is_active: true
      }])
      .select()
    
    if (error) throw error
    return data[0]
  },

  async rotate(agentId, newApiKey) {
    // Désactiver l'ancienne clé
    await supabase
      .from('api_keys_loopchat_2024')
      .update({ is_active: false })
      .eq('agent_id', agentId)
    
    // Créer la nouvelle clé
    return await this.create(agentId, newApiKey)
  }
}

// Webhook Messages Services
export const webhookMessagesService = {
  async create(agentId, messageContent, senderData = {}) {
    const { data, error } = await supabase
      .from('webhook_messages_loopchat_2024')
      .insert([{
        agent_id: agentId,
        message_content: messageContent,
        sender_data: senderData,
        processed: false,
        response_sent: false
      }])
      .select()
    
    if (error) throw error
    return data[0]
  },

  async markAsProcessed(messageId) {
    const { data, error } = await supabase
      .from('webhook_messages_loopchat_2024')
      .update({ processed: true })
      .eq('id', messageId)
      .select()
    
    if (error) throw error
    return data[0]
  },

  async markResponseSent(messageId) {
    const { data, error } = await supabase
      .from('webhook_messages_loopchat_2024')
      .update({ response_sent: true })
      .eq('id', messageId)
      .select()
    
    if (error) throw error
    return data[0]
  }
}

// Conversations Services
export const conversationsService = {
  async getAll() {
    const { data, error } = await supabase
      .from('conversations_loopchat_2024')
      .select('*')
      .order('updated_at', { ascending: false })
    
    if (error) throw error
    return data
  },

  async create(conversation) {
    const { data, error } = await supabase
      .from('conversations_loopchat_2024')
      .insert([{
        conversation_id: conversation.id,
        title: conversation.title,
        agent_id: conversation.agentId
      }])
      .select()
    
    if (error) throw error
    return data[0]
  },

  async update(conversationId, updates) {
    const { data, error } = await supabase
      .from('conversations_loopchat_2024')
      .update({
        title: updates.title,
        updated_at: new Date()
      })
      .eq('conversation_id', conversationId)
      .select()
    
    if (error) throw error
    return data[0]
  },

  async delete(conversationId) {
    const { error } = await supabase
      .from('conversations_loopchat_2024')
      .delete()
      .eq('conversation_id', conversationId)
    
    if (error) throw error
    return true
  }
}

// Messages Services
export const messagesService = {
  async getByConversation(conversationId) {
    const { data, error } = await supabase
      .from('messages_loopchat_2024')
      .select('*')
      .eq('conversation_id', conversationId)
      .order('timestamp', { ascending: true })
    
    if (error) throw error
    return data
  },

  async create(message) {
    const { data, error } = await supabase
      .from('messages_loopchat_2024')
      .insert([{
        message_id: message.id.toString(),
        conversation_id: message.conversationId,
        content: message.content,
        sender: message.sender,
        timestamp: message.timestamp
      }])
      .select()
    
    if (error) throw error
    return data[0]
  },

  async deleteByConversation(conversationId) {
    const { error } = await supabase
      .from('messages_loopchat_2024')
      .delete()
      .eq('conversation_id', conversationId)
    
    if (error) throw error
    return true
  }
}

// Statistics Services
export const statisticsService = {
  async getAll() {
    const { data, error } = await supabase
      .from('statistics_loopchat_2024')
      .select('*')
    
    if (error) throw error
    return data
  },

  async updateInteractionCount(agentId) {
    const { data, error } = await supabase
      .from('statistics_loopchat_2024')
      .upsert({
        agent_id: agentId,
        interaction_count: 1,
        last_interaction: new Date(),
        updated_at: new Date()
      }, { onConflict: 'agent_id' })
      .select()
    
    if (error) {
      // If upsert fails, try to increment existing record
      const { data: existingData, error: fetchError } = await supabase
        .from('statistics_loopchat_2024')
        .select('interaction_count')
        .eq('agent_id', agentId)
        .single()
      
      if (!fetchError && existingData) {
        const { data: updateData, error: updateError } = await supabase
          .from('statistics_loopchat_2024')
          .update({
            interaction_count: existingData.interaction_count + 1,
            last_interaction: new Date(),
            updated_at: new Date()
          })
          .eq('agent_id', agentId)
          .select()
        
        if (updateError) throw updateError
        return updateData[0]
      }
      throw error
    }
    
    return data[0]
  }
}

// User Settings Services
export const userSettingsService = {
  async get(userId = 'default') {
    const { data, error } = await supabase
      .from('user_settings_loopchat_2024')
      .select('*')
      .eq('user_id', userId)
      .single()
    
    if (error && error.code !== 'PGRST116') throw error
    return data
  },

  async update(userId = 'default', settings) {
    const { data, error } = await supabase
      .from('user_settings_loopchat_2024')
      .upsert({
        user_id: userId,
        language: settings.language,
        settings: settings.settings || {},
        updated_at: new Date()
      })
      .select()
    
    if (error) throw error
    return data[0]
  }
}