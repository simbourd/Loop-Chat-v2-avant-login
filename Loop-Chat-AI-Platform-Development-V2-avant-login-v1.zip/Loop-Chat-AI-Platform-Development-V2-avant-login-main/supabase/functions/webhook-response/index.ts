import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    // Extract agent ID from URL path
    const url = new URL(req.url)
    const pathParts = url.pathname.split('/')
    const agentId = pathParts[pathParts.length - 1]

    if (!agentId) {
      return new Response(
        JSON.stringify({ error: 'Agent ID is required' }),
        { 
          status: 400, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      )
    }

    // Verify API key
    const authHeader = req.headers.get('authorization')
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return new Response(
        JSON.stringify({ error: 'Authorization header required' }),
        { 
          status: 401, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      )
    }

    const apiKey = authHeader.replace('Bearer ', '')
    
    // Initialize Supabase client
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? ''
    )

    // Verify API key and get agent
    const { data: agent, error: agentError } = await supabase
      .from('agents_loopchat_2024')
      .select('*')
      .eq('agent_id', agentId)
      .eq('api_key', apiKey)
      .single()

    if (agentError || !agent) {
      return new Response(
        JSON.stringify({ error: 'Invalid API key or agent not found' }),
        { 
          status: 401, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      )
    }

    // Parse request body
    const body = await req.json()
    const { message, response, conversation_id } = body

    // Store the incoming message
    const { data: webhookMessage, error: messageError } = await supabase
      .from('webhook_messages_loopchat_2024')
      .insert([{
        agent_id: agentId,
        message_content: message || '',
        sender_data: body,
        processed: true,
        response_sent: true
      }])
      .select()
      .single()

    if (messageError) {
      console.error('Error storing webhook message:', messageError)
    }

    // If there's a conversation_id, store the response as a message
    if (conversation_id && response) {
      const { error: responseError } = await supabase
        .from('messages_loopchat_2024')
        .insert([{
          message_id: `msg_${Date.now()}`,
          conversation_id: conversation_id,
          content: response,
          sender: 'ai',
          timestamp: new Date().toISOString()
        }])

      if (responseError) {
        console.error('Error storing AI response:', responseError)
      }
    }

    // Update agent statistics
    const { error: statsError } = await supabase
      .from('statistics_loopchat_2024')
      .upsert({
        agent_id: agentId,
        interaction_count: 1,
        last_interaction: new Date(),
        updated_at: new Date()
      }, { onConflict: 'agent_id' })

    if (statsError) {
      console.error('Error updating statistics:', statsError)
    }

    // Return success response
    return new Response(
      JSON.stringify({ 
        success: true, 
        message: 'Response received and processed',
        agent_name: agent.name,
        timestamp: new Date().toISOString()
      }),
      { 
        status: 200, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    )

  } catch (error) {
    console.error('Webhook error:', error)
    return new Response(
      JSON.stringify({ error: 'Internal server error' }),
      { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    )
  }
})